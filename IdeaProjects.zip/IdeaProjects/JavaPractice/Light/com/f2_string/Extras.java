package com.f2_string;
import java.util.*;

public class Extras {

    public static void main(String[] args) {
        String s = "  hello world  ";
        s = reverseWords(s);
        System.out.println(s);
    }
    public String reverseWordsBuiltin(String s) {
        String[] words = s.trim().split(" +");
        Collections.reverse(Arrays.asList(words));
        return String.join(" ", words);
    }
    public static String reverseWords(String s) {

        StringBuilder sb = new StringBuilder();
        List<String> list = new ArrayList<>();
        int n = s.length();
        int i = 0;
        while (i < n) {
            while (i < n && s.charAt(i) == ' ') i++;
            StringBuilder temp = new StringBuilder();
            while (i < n && s.charAt(i) != ' ') {
                temp.append(s.charAt(i));
                i++;
            }
            list.add(temp.toString());
        }
        for (int j=list.size()-1; j > 0; j--) {
            sb.append(list.get(j)).append(" ");
        }
        sb.append(list.get(0));
        return sb.toString();
    }
}
