package com.f8_recursion.r5_backTrackking;
import java.util.*;

public class MColor {

    public static void main(String[] args) {

    }

    public static boolean graphColoring(boolean[][] graph, int colors, int vertex) {

        Map<Integer, List<Integer>> adj = new HashMap<>();

        for (int i=0; i<vertex; i++) {
            adj.put(i, new ArrayList<>());
        }

        for (int i = 0; i < vertex; i++) {
            for (int j = 0; j < graph[0].length; j++) {
                if (graph[i][j]) {
                    adj.get(i).add(j);
                    adj.get(j).add(i);
                }
            }
        }
        int[] assColors = new int[vertex];
        return solve(0, adj, assColors, colors, vertex);
    }

    private static boolean solve(int curVertex, Map<Integer, List<Integer>> adj, int[] assColors, int colors, int noOfVertices) {
        if (curVertex == noOfVertices) return true;

        for (int i = 1; i <= colors; i++) {
            if (isSafe (adj, assColors, i, curVertex)){
                assColors[curVertex] = i;
                if (solve(curVertex+1, adj, assColors, colors, noOfVertices)) {
                    return true;
                }
                assColors[curVertex] = 0;
            }
        }
        return false;
    }
    // check for current node adjacency , if any assigned in color in adjacency is not valid
    private static boolean isSafe(Map<Integer, List<Integer>> adj, int[] assColors, int curColor, int curVertex) {
        for (int it : adj.get(curVertex)) {
            if (assColors[it] == curColor) return false;
        }
        return true;
    }
}
