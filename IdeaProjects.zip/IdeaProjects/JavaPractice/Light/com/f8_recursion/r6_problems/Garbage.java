package com.f8_recursion.r6_problems;
import java.util.*;

public class Garbage {
    private final static Scanner sc  = new Scanner(System.in);
    public static void main(String[] args) {

    }

}
