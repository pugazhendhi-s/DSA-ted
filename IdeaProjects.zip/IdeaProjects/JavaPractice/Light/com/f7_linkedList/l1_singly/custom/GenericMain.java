package com.f7_linkedList.l1_singly.custom;


public class GenericMain {
    public static void main(String[] args) {
        mergeTwoLists();
    }
    public static void mergeTwoLists(){

    }
    /*public static void insertRec(){
        GenericLL<Integer> list = new GenericLL<>();
        list.insertRec(0, 3);
        list.insertRec(1, 9);
        list.insertRec(2, 7);
        list.insertRec(3, 6);
        list.insertRec(0, 1);
        list.insertRec(1, 2);
        list.insertRec(6, 1);
        System.out.println(list);
    }
    public static void removeDuplicate() {
        GenericLL<Integer> list = new GenericLL<>();
        list.add(1);
        list.add(1);
        list.add(1);
        list.add(2);
        list.add(2);
        list.add(3);
        list.add(4);
        list.add(4);
        list.deleteDuplicates();
        System.out.println(list);
    }
    public static void gll(){
//        GenericLL<Integer> list = new GenericLL<>();
//        list.addFirst(3);
//        list.addFirst(9);
//        list.addFirst(5);
//        list.addFirst(7); // this first element
//        list.addLast(99);
//        list.addLast(21);
//        list.add(2, 100);
//        list.add(7, 111);
//        list.add(777);
//        list.show();
//        System.out.println(list.removeFirst());
//        System.out.println(list.removeLast());
//        System.out.println(list.remove(2));
//        list.show();
        GenericLL<String> list = new GenericLL<>();
        list.addFirst("abc");
        list.addFirst("def");
        list.addFirst("ghi");
        list.addFirst("jkl"); // this first element
        list.add("mno");
        list.add("pqr");
        list.add(2, "DEF");
        list.add(7, "stu");
        list.add("vwx");
        //System.out.println(list.removeFirst());
        System.out.println(list.removeLast());
        System.out.println(list.remove(2));
    }*/
}
