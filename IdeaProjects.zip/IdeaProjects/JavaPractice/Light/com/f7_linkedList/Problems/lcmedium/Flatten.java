package com.f7_linkedList.Problems.lcmedium;

public class Flatten {

    private static class Node {
        int val;
        Node next;
        Node bottom;

        public Node(int val) {
            this.val = val;
            this.next = null;
            this.bottom = null;
        }

        public Node(int val, Node next, Node bottom) {
            this.val = val;
            this.next = next;
            this.bottom = bottom;
        }
    }
    
    public static void main(String[] args) {
        
    }

    public Node flatten(Node root) {

        if (root == null || root.next == null) {
            return root;
        }
        root.next = flatten(root.next);

        root = merge(root, root.next);
        return root;
    }

    public Node merge(Node a, Node b) {

        Node head = new Node(0);
        Node node = head;
        while (a != null && b != null) {
            if (a.val <= b.val) {
                node.bottom = a;
                node = node.bottom;
                a = a.bottom;
            }
            else {
                node.bottom = b;
                node = node.bottom;
                b = b.bottom;
            }
        }
        node.bottom = (a != null) ? a : b;
        return head.bottom;
    }
}
