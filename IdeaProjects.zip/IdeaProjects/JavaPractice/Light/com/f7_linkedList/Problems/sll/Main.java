package com.f7_linkedList.Problems.sll;

public class Main {
    public static void main(String[] args) {
        LL l1 = new LL();
        l1.add(5);
        l1.add(3);
        l1.add(13);
        l1.add(3);
        l1.add(8);

        System.out.println(l1);
        l1.removeNodes(l1);
        System.out.println(l1);
    }
}
