package com.ff2_dp.t6_longest;
import java.util.*;

public class LISK {

    public static void main(String[] args) {
        int[] A = {7,2,3,4};
        int K = 8;
        int[] result = minLengthIncSubseqAtleastK(A, K);
        System.out.println("Minimum length of increasing subsequence: " + result[0]);
        System.out.println("Sum of all elements in increasing subsequence: " + result[1]);
    }

    public static int[] minLengthIncSubseqAtleastK(int[] A, int K) {
        int n = A.length;
        int[] dp = new int[n];
        int[] sum = new int[n];
        Arrays.fill(dp, 1);
        Arrays.fill(sum, A[0]);

        for (int i = 1; i < n; i++) {
            for (int j = 0; j < i; j++) {
                if (A[i] > A[j]) {
                    if (dp[i] < dp[j] + 1) {
                        dp[i] = dp[j] + 1;
                        sum[i] = sum[j] + A[i];
                    }
                }
            }
        }

        int minLength = Integer.MAX_VALUE;
        int minSum = Integer.MAX_VALUE;
        for (int i = 0; i < n; i++) {
            if (sum[i] >= K && dp[i] < minLength) {
                minLength = dp[i];
                minSum = sum[i];
            }
        }

        if (minLength == Integer.MAX_VALUE) {
            return new int[]{-1, -1};
        } else {
            return new int[]{minLength, minSum};
        }
    }

}
