package com.f9_queueStack.stack.leetCode.medium;

import java.util.Stack;

public class s_Sumof_Subarray_Ranges {

    public static void main(String[] args) {

    }
    public long subArrayRanges(int[] nums) {

        int n = nums.length;
        long res = 0;
        Stack<Integer> stack = new Stack<>();

        for (int r = 0; r <= n; r++) { // subtracting minimum values;
            while ( !stack.empty() && ((r == n) || nums[stack.peek()] >= nums[r])) {
                int m = stack.pop();
                int l = stack.empty() ? -1 : stack.peek();
                res -= (long)nums[m] * (r-m) * (m-l);
            }
            stack.push(r);
        }
        stack.clear();  // adding maximum vales
        for (int r = 0; r <= n; r++) {
            while ( !stack.empty() && ((r == n) || nums[stack.peek()] <= nums[r])) {
                int m = stack.pop();
                int l = stack.empty() ? -1 : stack.peek();
                res += (long)nums[m] * (r-m) * (m-l);
            }
            stack.push(r);
        }
        return res;
    }

}
