package com.f9_queueStack.stack.custom;

public class StackException extends Exception{
    public StackException(String message){
        super(message);
    }
}
