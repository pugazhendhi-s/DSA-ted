package com.f9_queueStack.implementation;


public class QueueNode {

    int val;
    QueueNode next;

    public QueueNode(int val) {
        this.val = val;
        next = null;
    }
}
