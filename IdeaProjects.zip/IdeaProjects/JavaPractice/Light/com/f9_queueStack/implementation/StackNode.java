package com.f9_queueStack.implementation;

public class StackNode {

    int val;
    StackNode next;

    public StackNode(int val) {
        this.val = val;
        this.next = null;
    }
}
