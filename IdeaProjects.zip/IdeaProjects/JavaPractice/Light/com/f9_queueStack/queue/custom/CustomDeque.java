package com.f9_queueStack.queue.custom;

import java.util.ArrayDeque;
import java.util.Deque;

public class CustomDeque {
    public static void main(String[] args) {
        Deque<Integer> deque = new ArrayDeque<>();
        deque.add(5);
        deque.add(3);
        deque.add(7);

    }
}
