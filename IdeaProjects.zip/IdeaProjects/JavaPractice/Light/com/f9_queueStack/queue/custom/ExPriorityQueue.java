package com.f9_queueStack.queue.custom;

public class ExPriorityQueue {
    public static void main(String[] args) {
       
    }
}