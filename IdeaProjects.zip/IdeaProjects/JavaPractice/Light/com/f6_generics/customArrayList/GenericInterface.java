package com.f6_generics.customArrayList;

public interface GenericInterface<T> {
    default void love(){
        System.out.println("Fire");
    }
}
