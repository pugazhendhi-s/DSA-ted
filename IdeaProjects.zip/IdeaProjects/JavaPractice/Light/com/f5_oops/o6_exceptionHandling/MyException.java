package com.f5_oops.o6_exceptionHandling;

public class MyException extends Exception{
    public MyException(String message){
        super(message);
    }
}
