package com.f5_oops.o4_theory;

public interface Interfaces {
    void love();
    void rugg();
}
