package com.f5_oops.o4_theory;

public abstract class A implements Interfaces{//implements Interfaces{

    abstract void hello();
    void ref(){
        System.out.println("bruh");
    }
}
