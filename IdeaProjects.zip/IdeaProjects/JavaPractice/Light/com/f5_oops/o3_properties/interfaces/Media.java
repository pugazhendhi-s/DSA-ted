package com.f5_oops.o3_properties.interfaces;

public interface Media {
    void start();
    void stop();
}
