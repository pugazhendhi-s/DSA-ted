package com.f5_oops.o3_properties.interfaces.extend;

public interface Misa extends Light{
    void misaAmane();
}
