package com.f5_oops.o3_properties.interfaces.nested;

public class Main {
    public static void main(String[] args) {

        B b = new B();
        System.out.println(b.isOdd(6));
    }
}
