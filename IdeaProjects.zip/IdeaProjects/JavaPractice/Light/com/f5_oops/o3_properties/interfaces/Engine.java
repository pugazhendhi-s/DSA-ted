package com.f5_oops.o3_properties.interfaces;

public interface Engine {

    int price = 78_000; // static final inbuilt

    void start();
    void stop();
    void acc();

}
