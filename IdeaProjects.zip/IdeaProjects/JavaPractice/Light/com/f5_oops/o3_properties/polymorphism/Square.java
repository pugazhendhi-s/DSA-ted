package com.f5_oops.o3_properties.polymorphism;

public class Square extends Shapes{
    @Override
    void area(){
        System.out.println("Area of square is [l * l] ");
    }
}
