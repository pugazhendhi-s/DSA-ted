package com.f5_oops.o3_properties.inheritance;

public class BoxColor extends BoxWeight{
    // this hierarchical inheritance
}
