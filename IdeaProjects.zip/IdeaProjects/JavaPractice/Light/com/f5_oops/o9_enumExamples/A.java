package com.f5_oops.o9_enumExamples;

public interface A {
    void hello();
}
