package com.f1_arrays.sorting.algo;

public class Sorting {
    public static void main(String[] args) {

    }

}
