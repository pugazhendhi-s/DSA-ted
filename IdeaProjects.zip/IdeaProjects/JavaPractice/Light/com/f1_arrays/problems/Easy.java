package com.f1_arrays.problems;

import java.util.*;

import static java.util.Arrays.copyOf;
import static java.util.Arrays.sort;

public class Easy {
    public static void main(String[] args) {
        sortByFrequency();
    }

    public static void swap(int[] a, int i, int j) {
        int temp = a[i];
        a[i] = a[j];
        a[j] = temp;
    }

    static Scanner sc = new Scanner(System.in);

    static void pairSumArray() {
        /**
         * Input : [15, 13, 11, 10, 12, 10, 9, 8, 7, 5]
         * Output : [8, 7, 5, 3, 2]
         */
        int[] pair = {15, 13, 11, 10, 12, 10, 9, 8, 7, 5};   //8 7 5 3 2
        int n = 5;  // n * (n-1)/2 = va1+1;
        int[] a = new int[n];
        a[0] = (pair[0] + pair[1] - pair[n - 1]) / 2;  //  8+7 + 8+5 -(7+5)
        //  15+13 - 12 = 16 (7,5 removed, only 8,8 = 16 /2 =8 [0])
        for (int i = 0; i < n - 1; i++) {
            a[i + 1] = pair[i] - a[0];
        }
        System.out.println("Output : " + Arrays.toString(a));
    }

    static void triangleArray() {
        int[] a = {10, 21, 22, 100, 101, 200, 300};
        Arrays.sort(a);
        int count = 0;
        for (int i = 0; i < a.length - 2; i++) {
            for (int j = i + 1; j < a.length - 1; j++) {
                if (a[i] + a[j] > a[j + 1])
                    count++;
            }
        }
        System.out.println("Number of Triangle formed : " + count);
    }

    static void medianSortSubArray() {
        int[] a = {5, 15, 1, 3, 2, 8, 7, 9, 10, 6, 11, 4};
        int n = a.length;
        int median = 0;
        for (int i = 1; i < n; i++) {
            int j;
            int current = a[i];
            for (j = i - 1; j >= 0 && a[j] > current; j--) {
                a[j + 1] = a[j];
            }
            a[j + 1] = current;
            if (i % 2 != 0) {
                median = (a[i / 2] + a[(i / 2) + 1]) / 2;
                System.out.print(median + " ");
            } else {
                median = a[(i / 2)];
                System.out.print(median + " ");
            }
        }
        System.out.println("\n" + Arrays.toString(a));
    }

    static void minSwap() {
        int[] a = {9, 1, 3, 8};
        int[] temp = copyOf(a, a.length);
        sort(temp);
        int count = 0;
        for (int i = 0; i < a.length; i++) {
            if (temp[i] != a[i]) {
                count++;
                swap(a, i, indexOf(a, temp[i]));
            }
        }
        System.out.println(count);
    }

    static int indexOf(int[] arr, int element) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == element)
                return i;
        }
        return -1;
    }

    static void minSwapHash() {
        int[] a = {4, 3, 2, 1};
        int[] temp = copyOf(a, a.length);
        sort(temp);
        int count = 0;

        HashMap<Integer, Integer> hashMap = new HashMap<>();
        for (int i = 0; i < a.length; i++) {
            hashMap.put(a[i], i);
        }

        for (int i = 0; i < a.length; i++) {
            if (temp[i] != a[i]) {
                count++;
                int init = a[i];
                swap(a, i, hashMap.get(temp[i]));
                hashMap.put(init, hashMap.get(temp[i]));
                hashMap.put(temp[i], i);
            }
        }
        System.out.println(Arrays.toString(a));
        System.out.println("Swap count : " + count);
    }

    static void subArrayUnsorted_toSorted() {
        int[] a = {10, 12, 20, 30, 25, 40, 32, 31, 35, 50, 60};
        int n = a.length;
        System.out.println("Array Length = " + n);
        int s;
        int e;
        // (left to right)finding first element which greater than next element.
        for (s = 0; s < n - 1; s++) {
            if (a[s] > a[s + 1])
                break;
        }
        if (s == n - 1) {
            System.out.println("Array is already sorted");
            return;
        }
        // (right to left)finding element which small to previous element.
        for (e = n - 1; e >= 0; e--) {
            if (a[e] < a[e - 1])
                break;
        }
        // now traverse array from s+i < e to find minimum and maximum element.
        int min = Integer.MAX_VALUE;
        int max = Integer.MIN_VALUE;

        for (int i = s + 1; i < e; i++) { // till > s and e < are sorted, so s+1, e-1
            if (a[i] < min)
                min = a[i];
            if (a[i] > max)
                max = a[i];
        }
        for (int i = 0; i < s; i++) {
            if (a[i] > min) {
                s = i;
                break;
            }
        }
        for (int i = n - 1; i >= e; i--) {
            if (a[i] < max) {
                e = i;
                break;
            }
        }
        System.out.printf("The unsorted subarray which makes the given array \n" +
                "sorted lies between the indexes (%d, %d), Values (%d, %d)", s, e, a[s], a[e]);
    }

    static void closestPairSum() {
        // Two Pointer Technique
        System.out.println("Closest pair to sum in two sorted arrays");
        int[] a = {1, 4, 5, 7};
        int[] b = {10, 20, 30, 40};
        int x = 32;
        int res_a = -1, res_b = -1;
        int diff = Integer.MAX_VALUE;
        int left = 0;
        int right = b.length - 1;  // left for array a and right for array b
        while (left < a.length && right >= 0) {
            if (Math.abs(a[left] + b[right] - x) < diff) {
                res_a = left;
                res_b = right;
                diff = Math.abs(a[left] + b[right] - x);
            }
            if (Math.abs(a[left] + b[right]) > x)
                right--;
            else
                left++;
        }
        System.out.printf("Closest pair to %d is (%d,%d) = %d", x, a[res_a], b[res_b], Math.abs(a[res_a] + b[res_b]));
    }

    static void tripletSum() {
        System.out.println("Triplet sum");
        int[] arr = {3, 2, 5, 0, 7, 1};
        int sum = 15;
        HashSet<Integer> set = new HashSet<>();
        outer:
        for (int i = 0; i < arr.length - 2; i++) {
            int cur_sum = sum - arr[i];
            for (int j = i + 1; j < arr.length; j++) {
                if (set.contains(cur_sum - arr[j])) {
                    System.out.printf("Triplet sum %d is (%d, %d, %d)", sum, arr[i], arr[j], cur_sum - arr[j]);
                    break outer;
                }
                set.add(arr[j]);
            }
        }

    }

    static void pairCounts() {
        List<Integer> a = new ArrayList<>(Arrays.asList(1, 1, 3, 1, 2, 1, 3, 3, 3, 3));
        HashSet<Integer> hs = new HashSet<>();
        int pair = 0;
        for (Integer integer : a) {
            if (!hs.contains(integer))
                hs.add(integer);
            else {
                pair++;
                hs.remove(integer);
            }
        }
        System.out.println(pair);
    }

    static void countOfInversions() {
        System.out.println("Count of Inversions");
        int[] a = {8, 4, 2, 1};
        int count = 0;
        for (int i = 0; i < a.length; i++) {
            for (int j = i + 1; j < a.length; j++) {
                if (a[i] > a[j])
                    count++;
            }
        }
        System.out.println("Count of inversions : " + count);
    }

    static void elementCount() {
        int[] arr = {2, 3, 4, 5, 6, 3, 3, 4, 22, 22, 2, 1};
        int n = arr.length;
        boolean[] visited = new boolean[n];
        for (int i = 0; i < n; i++) {
            int count = 1;
            if (visited[i])
                continue;
            for (int j = i + 1; j < n; j++) {
                if (arr[i] == arr[j]) {
                    count++;
                    //{ 0, 4, 5, 5, 6, 7, 7, 7 }
                    visited[j] = true;
                }
            }
            System.out.printf("Element : %d => Occurring : %d\n", arr[i], count);
        }
    }

    static void sortByFrequency() {
        System.out.println("Sort by Frequency");
        int[] a = {7, 7, 7, 7, 7, 2, 2, 3, 3, 3, 3, 3, 3};
        Arrays.sort(a);
        int[][] b = new int[a.length][2];
        int index = 0;
        b[index][0] = a[0];
        // Finding Frequency
        for (int i = 1; i < a.length; i++) {
            if (a[i] == a[i - 1])
                b[index][1] += 1;
            else {
                b[++index][0] = a[i];
            }
        }
        Arrays.sort(b, (x, y) -> y[1]-x[1]);

        for (int i = 0; i <= index; i++) {
            for (int j = 0; j <= b[i][1]; j++) {
                System.out.print(b[i][0]);
            }
            System.out.print(" ");
        }
    }


    static void alternativeSortSortedArray() {
        int[] a = {1, 9, 4, 2, 5, 7, 0, 3, 6};
        int[] b = new int[a.length];
        Arrays.sort(a);
        int i = 0, j = a.length - 1;
        int k = 0;
        while (i <= j) {
            b[k++] = a[j--];
            b[k++] = a[i++];
        }
        // if (a.length % 2 != 0) is array size is odd
            b[k] = a[i];
        System.out.println(Arrays.toString(b));
    }

    static void alternativeSort() {
        // Bubble sort
        System.out.println("Alternative Sort");
        int[] a = {1, 6, 9, 4, 3, 7, 8, 2, 0, 5};
        System.out.println(Arrays.toString(a));
        int len = a.length;
        for (int i = 0; i < len; i += 2) {
            for (int j = 0; j < len - 2 - i; j += 2) {
                if (a[j] < a[j + 2]) {
                    int temp = a[j];
                    a[j] = a[j + 2];
                    a[j + 2] = temp;
                }
            }
        }
        for (int i = 1; i < len; i += 2) {
            for (int j = 1; j < len - 1 - i; j += 2) {
                if (a[j] > a[j + 2]) {
                    int temp = a[j];
                    a[j] = a[j + 2];
                    a[j + 2] = temp;
                }
            }
        }

        System.out.println(Arrays.toString(a));
    }
}
