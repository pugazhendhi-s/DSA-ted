package com.ff1_nonlinear.trees.bt.traversals;

public class Pair {

    public int num;
    public TreeNode node;

    public Pair(TreeNode node, int num) {
        this.node = node;
        this.num = num;
    }
}
