package com.ff1_nonlinear.trees.bt;

public class Pair {
    public int num;
    public TreeNode node;

    public Pair(TreeNode node, int num) {
        this.node = node;
        this.num = num;
    }
}
