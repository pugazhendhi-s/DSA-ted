package com.ff1_nonlinear.graph.i1_UDG;

import java.util.*;

public class P2_Island {

    private final static int[][] directions = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}}; // 4 directions
    private final static int[][] directionsAdj = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}, {1, 1}, {1, -1}, {-1, 1}, {-1, -1}}; // directions

    public static void main(String[] args) {
        isLands();
    }

    public static void isLands() {

        char[][] grid = {
                {'1', '1', '0', '0', '0'},
                {'1', '1', '0', '0', '0'},
                {'0', '0', '1', '0', '0'},
                {'0', '0', '0', '1', '1'}
        };
        int islands = noIslands(grid);
        System.out.println(islands);
    }

    public static int numIslands(char[][] grid) {

        int islands = 0;

        for (int r = 0; r < grid.length; r++) {

            for (int c = 0; c < grid[0].length; c++) {
                if (grid[r][c] == '1') {
                    dfs(grid, r, c);
                    islands++;
                }
            }
        }
        return islands;
    }

    private static void dfs(char[][] grid, int r, int c) {
        // check edge cases
        if (r < 0 || c < 0 || r >= grid.length || c >= grid[0].length || grid[r][c] != '1')
            return;

        grid[r][c] = '0';

        for (int[] dir : directions) {
            dfs(grid, r + dir[0], c + dir[1]);
        }
    }

    // bfs

    public static int noIslands(char[][] grid) {
        int n = grid.length;
        int m = grid[0].length;
        boolean[][] vis = new boolean[n][m];
        int island = 0;

        for (int r = 0; r < n; r++) {
            for (int c = 0; c < m; c++) {
                if (!vis[r][c] && grid[r][c] == '1') {
                    island++;
                    bfs(r, c, grid, vis);
                }
            }
        }
        return island;
    }

    private static void bfs(int r, int c, char[][] grid, boolean[][] vis) {
        vis[r][c] = true;
        Queue<Pair> queue = new LinkedList<>();
        queue.offer(new Pair(r,c));

        while ( !queue.isEmpty()) {
            Pair p = queue.poll();
            int row = p.first;
            int col = p.second;

            for (int[] d : directions) {
                int nr = row + d[0];
                int nc = col + d[1];
                if (nr >= 0 && nr < grid.length && nc >= 0 && nc < grid[0].length
                        && !vis[nr][nc] && grid[nr][nc] == '1') {
                    vis[nr][nc] = true;
                    queue.offer(new Pair(nr, nc));
                }
            }
        }
    }


    public static void countDistinctIslands() {

        int[][] grid = {
                {1, 1, 0, 1, 1},
                {1, 0, 0, 0, 0},
                {0, 0, 0, 1, 1},
                {1, 0, 0, 1, 0}
        };
        int islands = countDI(grid);
        System.out.println(islands);
    }

    public static int countDI(int[][] grid) {

        int n = grid.length;
        int m = grid[0].length;
        boolean[][] vis = new boolean[n][m];
            
        Set<ArrayList<String>> isLands = new HashSet<>();
        
        for (int r=0; r<n; r++) {
            for (int c=0; c<m; c++) {
                if ( !vis[r][c] && grid[r][c] == 1) {
                    ArrayList<String> list = dfs(r, c, vis, grid, new ArrayList<>(), r, c);
                    isLands.add(list);
                }
            }
        }

        return isLands.size();
        
    }

    private static  ArrayList<String> dfs(int r, int c, boolean[][] vis, int[][] grid, ArrayList<String> list, int x, int y) {
        vis[r][c] = true;
        list.add((r-x) + " "+ (c-y));
        for (int[] dir : directions) {
            int nr = r + dir[0];
            int nc = r + dir[1];
            if (nr < 0 || nr >= grid.length || nc < 0 || nc >= grid[0].length || vis[nr][nc] || grid[nr][nc] == 0) {
                continue;
            }
            dfs(nr, nc, vis, grid, list, x, y);
        }
        return list;
    }
}
