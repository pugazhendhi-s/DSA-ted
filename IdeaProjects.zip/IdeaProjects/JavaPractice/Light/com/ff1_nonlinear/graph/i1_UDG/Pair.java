package com.ff1_nonlinear.graph.i1_UDG;

public class Pair {

    public int first;
    public int second;

    public Pair(int first, int second) {
        this.first = first;
        this.second = second;
    }
}
