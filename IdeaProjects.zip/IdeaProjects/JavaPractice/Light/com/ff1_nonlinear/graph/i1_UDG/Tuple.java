package com.ff1_nonlinear.graph.i1_UDG;

public class Tuple {

    int first;
    int second;
    int third;

    public Tuple(int first, int second, int third) {
        this.first = first;
        this.second = second;
        this.third = third;
    }
}