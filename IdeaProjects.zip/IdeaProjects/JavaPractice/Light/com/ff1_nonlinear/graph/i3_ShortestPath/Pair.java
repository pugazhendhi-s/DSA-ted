package com.ff1_nonlinear.graph.i3_ShortestPath;

public class Pair {

    public int first;
    public int second;

    public Pair(int first, int second) {
        this.first = first;
        this.second = second;
    }
}
