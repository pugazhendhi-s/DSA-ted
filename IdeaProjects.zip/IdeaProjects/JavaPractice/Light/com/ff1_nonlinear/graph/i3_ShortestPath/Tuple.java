package com.ff1_nonlinear.graph.i3_ShortestPath;

public class Tuple {

    int first;
    int second;
    int third;

    public Tuple(int first, int second, int third) {
        this.first = first;
        this.second = second;
        this.third = third;
    }
}