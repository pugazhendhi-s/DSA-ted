package com.ff1_nonlinear.graph.i3_ShortestPath;

import java.util.ArrayList;
import java.util.Arrays;

public class S4_BellmanFord {
    public static void main(String[] args) {

    }

    public static int[] bellmanFord(int V, ArrayList<ArrayList<Integer>> edges, int S) {

        int[] dist = new int[V];
        Arrays.fill(dist, (int)1e8);

        dist[S] = 0;

        // O(V x E)
        for(int i=1; i<=V; i++) {
            // perform n-1 relax to reach the shortest path,
            // but nth relax for check if it is a negative cycle

            for(ArrayList<Integer> ed : edges) {

                int u = ed.get(0);
                int v = ed.get(1);
                int wt = ed.get(2);

                if (dist[u] != (int)1e8 && dist[u] + wt < dist[v]) {

                    if(i == V) return new int[] {-1};  // nth relax to check for negative cycle

                    dist[v] = dist[u] + wt;
                }
            }
        }
        return dist;
    }
}
