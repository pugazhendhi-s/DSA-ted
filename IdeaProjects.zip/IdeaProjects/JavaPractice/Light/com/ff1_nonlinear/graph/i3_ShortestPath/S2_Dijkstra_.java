package com.ff1_nonlinear.graph.i3_ShortestPath;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.PriorityQueue;

public class S2_Dijkstra_ {

    public static void main(String[] args) {

    }

    public static int[] dijkstra(int V, ArrayList<ArrayList<ArrayList<Integer>>> adj, int S) {

        PriorityQueue<Pair> pq = new PriorityQueue<>(Comparator.comparingInt(x -> x.first));

        int[] d = new int[V];
        Arrays.fill(d, (int) 1e9);

        d[S] = 0;
        pq.offer(new Pair(0, S));

        while (!pq.isEmpty()) {

            Pair pair = pq.poll();   // u -> node, du -> node distance
            int du = pair.first;
            int u = pair.second;    // v - adjacent node , dv -> adjacent dist

            for (ArrayList<Integer> list : adj.get(u)) {
                int v = list.get(0);
                int dv = list.get(1);

                if (du + dv < d[v]) {
                    d[v] = du + dv;
                    pq.offer(new Pair(d[v], v));
                }
            }
        }
        return d;
    }
}
