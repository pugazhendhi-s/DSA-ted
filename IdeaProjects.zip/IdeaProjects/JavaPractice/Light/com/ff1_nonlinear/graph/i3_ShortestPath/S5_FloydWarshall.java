package com.ff1_nonlinear.graph.i3_ShortestPath;

import java.util.Arrays;

public class S5_FloydWarshall {

    public static void main(String[] args) {

    }

    public void shortest_distance(int[][] mat) {

        int n = mat.length;

        for (int i=0; i<n; i++) {
            for (int j=0; j<n; j++) {

                if(mat[i][j] == -1) mat[i][j] = (int)1e9;
                if(i == j) mat[i][j] = 0;
            }
        }
        // O(n^3)
        for (int k=0; k<n; k++) {
            for (int i=0; i<n; i++) {
                for (int j=0; j<n; j++) {
                    mat[i][j] =  Math.min(mat[i][j], mat[i][k] + mat[k][j]);
                }
            }
        }
        // to detect negative cycle
        for (int i = 0; i < n; i++) {
            if(mat[i][i] < 0) {
                System.out.println("The given matrix contains negative cycle");
                return;
            }
        }
        for (int i=0; i<n; i++) {
            for(int j=0; j<n; j++) {
                if(mat[i][j] == (int)1e9) mat[i][j] = -1;
            }
        }
    }

    public int findTheCity(int n, int[][] edges, int distanceThreshold) {

        int[][] dist = new int[n][n];
        int smallest = n; int city = 0;

        for (int[] d : dist) Arrays.fill(d, 10001);

        for (int[] e : edges) {
            int u = e[0], v = e[1], wt = e[2];
            dist[u][v] = dist[v][u] = wt;
        }

        for (int i=0; i<n; i++) dist[i][i] = 0;

        for (int k=0; k<n; k++) {
            for (int i=0; i<n; i++) {
                for (int j=0; j<n; j++) {
                    dist[i][j] =  Math.min(dist[i][j], dist[i][k] + dist[k][j]);
                }
            }
        }

        for (int i=0; i<n; i++) {
            int count = 0;

            for(int j=0; j<3; j++) {
                if(dist[i][j] <= distanceThreshold) count++;
            }
            if (count <= smallest) {
                smallest = count;
                city = i;
            }
        }
        return city;
    }
}
