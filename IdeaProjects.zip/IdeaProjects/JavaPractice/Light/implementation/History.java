package implementation;
import java.util.*;

public class History {

    public static void main(String[] args) {
        BrowserHistory bh = new BrowserHistory("leetcode");
        bh.visit("google");
        bh.visit("facebook");
        bh.visit("youtube");

        String back = bh.back(1);
        System.out.println(back);

        back = bh.back(1);
        System.out.println(back);

        String forward = bh.forward(1);
        System.out.println(forward);

        bh.visit("linkedin");

        forward = bh.forward(2);
        System.out.println(forward);

        back = bh.back(2);
        System.out.println(back);

        back = bh.back(7);
        System.out.println(back);

    }

    static class BrowserHistory {

        ArrayList<String> list;
        int curr, last;
        public BrowserHistory(String homepage) {
            list = new ArrayList<>();
            list.add(homepage);
            curr = last = 0;
        }

        public void visit(String url) {
            if (list.size() == curr+1) {
                curr++;
                list.add(url);
            }
            else {
                curr++;
                list.set(curr, url);
            }
            last = curr;
        }

        public String back(int steps) {
            curr = Math.max(curr-steps, 0);
            return list.get(curr);
        }

        public String forward(int steps) {
            curr = Math.min(curr+steps,last);
            return list.get(curr);
        }
    }

/**
 * Your BrowserHistory object will be instantiated and called as such:
 * BrowserHistory obj = new BrowserHistory(homepage);
 * obj.visit(url);
 * String param_2 = obj.back(steps);
 * String param_3 = obj.forward(steps);
 */
}
