package projects.twitter;
import java.util.*;

public class Twitter {
    private static class Node{
        int userId;
        int tweetId;

        public Node(int userId, int tweetId) {
            this.userId = userId;
            this.tweetId = tweetId;
        }
    }

    Map<Integer, Set<Integer>> map; // contains users and user followed in set
    LinkedList<Node> tweets = new LinkedList<>();

    public Twitter() {
        map = new HashMap<>();
    }

    public void postTweet(int userId, int tweetId) {
        tweets.add(new Node(userId, tweetId));
    }

    public List<Integer> getNewsFeed(int userId) {
        List<Integer> feeds = new ArrayList<>();

        // get user followers and user followed
        Set<Integer> followed = map.get(userId);
        for (int i = tweets.size()-1; i >= 0; i--) {
            int usId = tweets.get(i).userId;
            int twId = tweets.get(i).tweetId;

            if(followed != null && followed.contains(usId) || userId == usId)
                feeds.add(twId);

            if(feeds.size() == 10) break;
        }
        return feeds;
    }

    public void follow(int followerId, int followeeId) {
        map.computeIfAbsent(followerId, k -> new HashSet<>()); // // !map.containsKey(followerId)
        map.get(followerId).add(followeeId);
    }

    public void unfollow(int followerId, int followeeId) {
        if(map.containsKey(followerId))
            map.get(followerId).remove(followeeId);
    }
}
