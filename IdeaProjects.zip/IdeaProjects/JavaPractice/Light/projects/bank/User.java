package projects.bank;

public class User extends Person{

    public BankDetails b1; // has a relationship - composition

    public User(BankDetails b1, String name, String aadharNo, int age){
        this.b1 = b1;
        this.name = name;
        this.aadharNo = aadharNo;
        this.age = age;
    }

    @Override
    public String toString() {
        return "User Bank Details { " +
                "Bank Name = " + BankDetails.BANK_NAME +
                "\n\tAccount holder Name = " + b1.name +
                "\n\tAccount Number = " + b1.getAccNo() +
                "\n\tIFSC code = " + b1.ifsc +
                "\n\tAadharNo = " + aadharNo  +
                "\n\tAge = " + age +
                "\n\tBalance = " + b1.getBalance() +
                " }";
    }
}
