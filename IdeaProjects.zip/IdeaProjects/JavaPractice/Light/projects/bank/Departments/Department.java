package projects.bank.Departments;

public class Department {
    String departName;
    private static int noOfDepartments;
    int noOfEmployeesPerDepartment;
    double budgetPerDepartment;

    public Department(String departName, int noOfEmployeesPerDepartment, double budgetPerDepartment) {
        this.departName = departName;
        this.noOfEmployeesPerDepartment = noOfEmployeesPerDepartment;
        this.budgetPerDepartment = budgetPerDepartment;
        noOfDepartments++;
    }
}
