package projects.bank.Departments;

import projects.bank.User;

public class Update_BankDetails {
    User user;
}
