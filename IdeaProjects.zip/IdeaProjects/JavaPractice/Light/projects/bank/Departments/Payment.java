package projects.bank.Departments;

import projects.bank.InsufficientBalanceException;
import projects.bank.User;

public class Payment extends Department {
    public User user;
    public double amount;
    public String depositOrWithdrawal;
    public Payment(User user, String depositOrWithdrawal, double amount) throws InsufficientBalanceException {
        super("Payment", 5, 100000000.00);
        this.user = user;
        this.depositOrWithdrawal = depositOrWithdrawal;
        this.amount = amount;
        this.cashier();
    }
    public void cashier() throws InsufficientBalanceException {
        if(depositOrWithdrawal.equalsIgnoreCase("deposit"))
            user.b1.deposit(this.amount);
        else if(depositOrWithdrawal.equalsIgnoreCase("withdrawal"))
            user.b1.withdrawal(this.amount);
    }
}
