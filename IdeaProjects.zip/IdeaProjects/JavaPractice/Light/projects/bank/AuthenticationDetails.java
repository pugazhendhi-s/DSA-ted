package projects.bank;

public class AuthenticationDetails {
    private String userName;
    private String password;
}
