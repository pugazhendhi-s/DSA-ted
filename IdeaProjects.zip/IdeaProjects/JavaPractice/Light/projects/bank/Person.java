package projects.bank;

public class Person {
    public String name;
    public String aadharNo;
    public int age;

}
