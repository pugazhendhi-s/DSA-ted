package projects.bank;

import projects.bank.Departments.Department;

public class BankEmployee extends Person{

    int empId;
    String designation;
    private double salary;

    Department department;
    private AuthenticationDetails authDetails;

    public BankEmployee(int empId, String designation, double salary, Department department, AuthenticationDetails authDetails){

    }
}
