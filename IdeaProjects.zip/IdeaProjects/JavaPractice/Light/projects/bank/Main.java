package projects.bank;

import projects.bank.Departments.Payment;

public class Main {
    public static void main(String[] args){

        BankDetails b1 = new BankDetails("Misa", "SBI7143");
        User u1 = new User(b1, "Misa", "7484 7903 4007", 21);
        System.out.println(u1);
        try {
            Payment p1 = new Payment(u1, "deposit", 10000.00);
            System.out.println(u1);
            Payment p2  =new Payment(u1, "withdrawal", 3999.00);
            System.out.println(u1);
        }
        catch (InsufficientBalanceException exception){
            System.out.println(exception.getMessage());
        }
        // next user
        BankDetails b2 = new BankDetails("Kira", "SBI3417");
        User u2 = new User(b2, "Kira", "7484 4567 9870", 19);
        System.out.println(b2);
        try{
            Payment p3 = new Payment(u2, "deposit", 1000000.00);
            System.out.println(u2);
            Payment p4 = new Payment(u2, "withdrawal", 111111.00);
            System.out.println(u2);
        }
        catch (InsufficientBalanceException exception){
            System.out.println(exception.getMessage());
        }
    }


}
