package projects.bank;

public class BankDetails {
    public String name;
    private static int noOfAccounts;
    private final int accNo;
    public String ifsc;
    public final static String BANK_NAME = "SBI - Thalaivasal";
    private double balance;

    public BankDetails(String name, String ifsc){
        this.name = name;
        this.ifsc = ifsc;
        noOfAccounts++;
        this.accNo = noOfAccounts;
    }
    public int getAccNo(){
        return accNo;
    }
    public double getBalance() {
        return balance;
    }
    public void deposit(double amount){
        this.balance += amount;
    }
    public void withdrawal(double amount) throws InsufficientBalanceException{
        if(balance < amount)
            throw new InsufficientBalanceException("Sorry! Insufficient Balance..Transaction failed");
        this.balance -= amount;
    }
}
