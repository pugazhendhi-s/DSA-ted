package projects.ATM1;

public class Card {
    private String system;
    private String cardNo;
    private String cardHolder;
    private String pin;
    private double balance;
    boolean state; // active -> true / block - false
    // constructor
    public Card(){}

    public Card(String system, String cardNo, String cardHolder, String pin, double balance, boolean state) {
        this.system = system;
        this.cardNo = cardNo;
        this.cardHolder = cardHolder;
        this.pin = pin;
        this.balance = balance;
        this.state = state;
    }

    public String getSystem() {
        return system;
    }

    public void setSystem(String system) {
        this.system = system;
    }

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    public String getCardHolder() {
        return cardHolder;
    }

    public void setCardHolder(String cardHolder) {
        this.cardHolder = cardHolder;
    }

    public String getPin() {
        return pin;
    }

    public void setPin(String pin) {
        this.pin = pin;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public boolean isState() {
        return state;
    }

    public void setState(boolean state) {
        this.state = state;
    }

    @Override
    public String toString() {
        return "Card { " +
                "System ='" + system + '\'' +
                ", Card Number ='" + cardNo + '\'' +
                ", Card Holder ='" + cardHolder + '\'' +
                ", Pin ='" + pin + '\'' +
                ", Balance =" + balance +
                ",State =" + state +
                " }";
    }
}
