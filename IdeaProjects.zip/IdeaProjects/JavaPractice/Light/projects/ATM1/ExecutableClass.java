package projects.ATM1;

import projects.ATM1.ATMException.InsufficientBalanceException;
import projects.ATM1.ATMException.ValidWithdrawalAmount;
import projects.ATM1.ATMException.WrongPasswordException;

import java.util.Scanner;

public class ExecutableClass {
    private static final Scanner sc = new Scanner(System.in);
    static Card card1 = new Card("Rupay", "9860 1234 4555 9012", "Aminov Abror", "0919", 100000, true);
    static Card card2 = new Card("Visa", "1921 1010 5544 9013", "Ozodov Doniyor", "0309", 1000, true);
    static Card card3 = new Card("Master Card", "7654 9090 1214 9014", "Mirziyoyev Shuhrat", "1909", 1400, true);
    static Card card4 = new Card("Union Pay", "9077 1234 2321 9015", "Asqarov Abbos", "4309", 43000, true);
    static Card card5 = new Card("Maestro", "9090 9090 9090 9090", "Sherjonov Jahongir", "0909", 2000000, true);

    private static final Card[] cards = {card1, card2, card3, card4, card5}; // massive database
    public static ServiceATM service = new ServiceImplement();
    public static void display(Card inserted) throws InsufficientBalanceException, ValidWithdrawalAmount, WrongPasswordException {
        if (inserted != null){
            if(service.checkPin(inserted)){
                while (true){
                    System.out.println("----------------------");
                    System.out.println("1. View Account details.");
                    System.out.println("----------------------");
                    System.out.println("2. Cash withdrawal");
                    System.out.println("----------------------");
                    System.out.println("3. Cash Deposit");
                    System.out.println("----------------------");
                    System.out.println("4. Pin Generation / Change Pin");
                    System.out.println("----------------------");
                    System.err.println("5. Exit");
                    int options = Integer.parseInt(sc.nextLine());
                    switch (options){
                        case 1:
                            System.out.println(inserted);
                            break;
                        case 2:
                            service.withdrawal(inserted);
                            break;
                        case 3:
                            service.deposit(inserted);
                            break;
                        case 4:
                            service.changePin(inserted);
                        case 5:
                            return;
                    }
                }
            }
        }
    }
    public static Card getCard(String cardNo) throws InValidCardException {
        for (Card card : cards){
            if(card.getCardNo().equals(cardNo)){
                if(card.isState())
                    return card;
                else {
                    System.err.println("The Card has been blocked! Please contact respective bank");
                    return null;
                }
            }
        }
        throw new InValidCardException("Card doesn't exist!..");
    }

}
