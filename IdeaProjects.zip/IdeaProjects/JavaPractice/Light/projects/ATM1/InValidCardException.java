package projects.ATM1;

public class InValidCardException extends Exception {
    public InValidCardException(String msg){
        super(msg);
    }
}
