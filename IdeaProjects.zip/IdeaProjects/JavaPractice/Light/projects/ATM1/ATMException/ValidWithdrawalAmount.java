package projects.ATM1.ATMException;

public class ValidWithdrawalAmount extends Throwable {
    public ValidWithdrawalAmount(String msg) {
        super(msg);
    }
}
