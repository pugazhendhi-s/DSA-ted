package projects.ATM1.ATMException;

public class WrongPasswordException extends Exception{

    public WrongPasswordException(String msg){
        super(msg);
    }
}
