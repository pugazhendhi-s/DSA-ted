package projects.ATM1;

import projects.ATM1.ATMException.InsufficientBalanceException;
import projects.ATM1.ATMException.ValidWithdrawalAmount;
import projects.ATM1.ATMException.WrongPasswordException;

import java.util.Scanner;

public class ServiceImplement implements ServiceATM{

    static int num;
    static Scanner sc = new Scanner(System.in);
    @Override
    public void changePin(Card card) throws WrongPasswordException {
        String pin;
        System.out.println("Enter your current pin");
        pin = sc.nextLine();
        if(card.getPin().equals(pin)){
            System.out.println("Enter your new pin");
            card.setPin(sc.nextLine());
            System.out.println("\n\n");
            System.out.println("Successfully completed!. Your pin has been changed");
        }
        else
            throw new WrongPasswordException("Your current password is not correct");
    }

    @Override
    public void balance(Card card) {
        System.out.println("In your card account : "+card.getBalance());
    }

    @Override
    public void withdrawal(Card card) throws InsufficientBalanceException, ValidWithdrawalAmount {
        Cash cash = new Cash();
        System.out.print("Available cash type");
        if(cash.getNoOf100() > 0){
            System.out.print("100,  ");
        }
        if(cash.getNoOf200() > 0){
            System.out.print("200,  ");
        }
        if (cash.getNoOf500() > 0){
            System.out.print("500,  ");
        }
        if(cash.getNoOf2000() > 0){
            System.out.print("2000");
        }
        System.out.println("Enter the amount to withdrawal");
        double amount = Double.parseDouble(sc.nextLine());
        if(amount > card.getBalance()){
            throw new InsufficientBalanceException("Insufficient Balance!. Transaction Failed");
        }
        if(amount > cash.getTotalCashInATM()){
            throw new InsufficientBalanceException("Cash Unavailable!. Please visit nearby ATM");
        }
        int c100 = 0, c200 = 0, c500 = 0, c2000 = 0;
        if(amount / 2000 >= 1){
            c2000 = (int) (amount / 2000 <= cash.getNoOf2000() ? amount / 2000 : cash.getNoOf2000());
            amount = amount - (c2000 * 2000);
        }
        if(amount / 500 >= 1){
            c500 = (int) (amount / 500 <= cash.getNoOf500() ? amount / 500 : cash.getNoOf500());
            amount = amount - (c500 * 500);
        }
        if(amount / 200 >= 1){
            c200 = (int) (amount / 200 <= cash.getNoOf200() ? amount / 200 : cash.getNoOf200());
            amount = amount - (c200 * 200);
        }
        if(amount / 100 >= 1){
            c100 = (int) (amount / 100 <= cash.getNoOf2000() ? amount / 100 : cash.getNoOf100());
            amount = amount - (c100 * 100);
        }
        if(amount != 0){
            throw new ValidWithdrawalAmount("Please withdraw valid type of amount..");
        }
        cash.setNoOf2000(cash.getNoOf2000() - c2000);
        cash.setNoOf500(cash.getNoOf500() - c500);
        cash.setNoOf200(cash.getNoOf200() - c200);
        cash.setNoOf100(cash.getNoOf100() - c100);
        cash.setTotalCashInATM(cash.getTotalCashInATM() - amount);
        // user balance
        card.setBalance(card.getBalance() - amount);
        System.out.println("Please Collect your cash");
        if(c2000 > 0){
            System.out.println("2000 = " + c2000);
        }
        if(c500 > 0){
            System.out.println("500 = " + c500);
        }
        if(c200 > 0){
            System.out.println("200 = " + c200);
        }
        if(c100 > 0){
            System.out.println("100 = " + c100);
        }
        System.out.println("Thank you");
        System.exit(0);
    }
    @Override
    public boolean checkPin(Card card) throws WrongPasswordException {
        //boolean check = false;
        int i=1;
        while (i <= 3) {
            System.out.println("Enter your pin");
            String pin = sc.nextLine();
            if(pin.equals(card.getPin()))
                return true;
            else{
                System.out.println("Your pin is incorrect");
                if(i == 3){
                    card.setState(false);
                    throw new WrongPasswordException("Your attempting wrong pin more than 3 times. Contact bank for support");
                }
            }
            i++;
        }
        return false;
    }
    @Override
    public void deposit(Card card) {
        System.out.println("Enter the amount to be deposited");
        double amount = Double.parseDouble(sc.nextLine());
        System.out.println("No of 100 rupee note");
        int c100 = Integer.parseInt(sc.nextLine());
        System.out.println("No of 200 rupee note");
        int c200 = Integer.parseInt(sc.nextLine());
        System.out.println("No of 500 rupee note");
        int c500 = Integer.parseInt(sc.nextLine());
        System.out.println("No of 2000 rupee note");
        int c2000 = Integer.parseInt(sc.nextLine());

        // adding money in user account
        card.setBalance(card.getBalance() + amount);

        // adding money in atm
        Cash cash = new Cash();
        cash.setNoOf100(cash.getNoOf100() + c100);
        cash.setNoOf200(cash.getNoOf200() + c200);
        cash.setNoOf500(cash.getNoOf500() + c500);
        cash.setNoOf2000(cash.getNoOf2000() + c2000);

        cash.setTotalCashInATM(cash.getTotalCashInATM() + amount);
    }
}
