package projects.ATM1;

import projects.ATM1.ATMException.InsufficientBalanceException;
import projects.ATM1.ATMException.ValidWithdrawalAmount;
import projects.ATM1.ATMException.WrongPasswordException;

public interface ServiceATM {
    void changePin(Card card) throws WrongPasswordException;
    void balance(Card card);
    void withdrawal(Card card) throws InsufficientBalanceException, ValidWithdrawalAmount;
    void deposit(Card card);
    boolean checkPin(Card card) throws WrongPasswordException;

}
