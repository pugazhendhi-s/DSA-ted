package projects.ATM1;

public class Cash {
    private int noOf100 = 1000;
    private int noOf200 = 750;
    private int noOf500 = 500;
    private int noOf2000 = 500;
    private double totalCashInATM = (double)(noOf100 * 100) + (noOf200 * 200)+ (noOf500 * 500) + (noOf2000 * 2000);

    public int getNoOf100() {
        return noOf100;
    }

    public void setNoOf100(int noOf100) {
        this.noOf100 = noOf100;
    }

    public int getNoOf200() {
        return noOf200;
    }

    public void setNoOf200(int noOf200) {
        this.noOf200 = noOf200;
    }

    public int getNoOf500() {
        return noOf500;
    }

    public void setNoOf500(int noOf500) {
        this.noOf500 = noOf500;
    }

    public int getNoOf2000() {
        return noOf2000;
    }

    public void setNoOf2000(int noOf2000) {
        this.noOf2000 = noOf2000;
    }

    public double getTotalCashInATM() {
        return totalCashInATM;
    }

    public void setTotalCashInATM(double totalCashInATM) {
        this.totalCashInATM = totalCashInATM;
    }
}
