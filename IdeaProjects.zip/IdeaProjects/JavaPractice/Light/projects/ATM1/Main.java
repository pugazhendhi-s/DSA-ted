package projects.ATM1;

import projects.ATM1.ATMException.InsufficientBalanceException;
import projects.ATM1.ATMException.ValidWithdrawalAmount;
import projects.ATM1.ATMException.WrongPasswordException;

import java.util.Scanner;
import static projects.ATM1.ExecutableClass.getCard;

public class Main {
    public static void main(String[] args) throws InsufficientBalanceException, ValidWithdrawalAmount, WrongPasswordException {
        Scanner sc = new Scanner(System.in);

        while (true){
            try {
                System.out.println("Enter your card number");
                Card inserted = getCard(sc.nextLine());
                ExecutableClass.display(inserted);
                System.out.println("Enter Exit case");
                int ch = Integer.parseInt(sc.nextLine());
                if (ch == 0)
                    System.exit(0);
            }
            catch (ValidWithdrawalAmount | InsufficientBalanceException | WrongPasswordException e){
                System.out.println(e.getMessage());
            }
            catch (Exception e){
                System.out.println(e.getMessage());
            }
        }
    }
}
