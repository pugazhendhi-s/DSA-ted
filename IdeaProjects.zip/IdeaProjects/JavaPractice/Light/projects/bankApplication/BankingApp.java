package projects.bankApplication;

import java.util.Scanner;

public class BankingApp {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        // create initials accounts
        System.out.println("How many number of customers do you want to input");
        int n = Integer.parseInt(sc.nextLine());
        BankDetails[] C = new BankDetails[n];
        for (int i = 0; i < n; i++) {
            C[i] = new BankDetails();
            C[i].openAccount();
        }
        int choice;
        do{
            System.out.println("****  Banking System Application  ****");
            System.out.println(" 1 -> Display all account details\n" +
                                    " 2 -> Search by Account Number\n" +
                                    " 3 -> Deposit the amount\n" +
                                    " 4 -> WithDraw the amount\n" +
                                    " 5 -> Exit");
            choice = Integer.parseInt(sc.nextLine());
            switch (choice){
                case 1:
                    for (BankDetails user : C) {
                        user.showAccount();
                    }
                    break;
                case 2:
                    System.out.println("Enter account number you want to search");
                    String accNo = sc.nextLine();
                    boolean found = false;
                    for (int i = 0; i < C.length; i++) {
                        found = C[i].search(accNo); // do enhance for loop as before
                        if (found)
                            break;
                    }
                    if(!found)
                        System.out.println("Search failed! Account doesn't exist");
                    break;
                case 3:
                    System.out.println("Enter Account Number");
                    accNo = sc.nextLine();
                    found = false;
                    for (BankDetails users : C) {
                        found = users.search(accNo);
                        if (found) {
                            users.deposit();
                            break;
                        }
                    }
                    if(!found)
                        System.out.println("Search failed! Account doesn't exist");
                    break;
                case 4:
                    System.out.println("Enter account Number");
                    accNo = sc.nextLine();
                    found = false;
                    for (BankDetails users : C) {
                        found = users.search(accNo);
                        if (found) {
                            users.withdrawal();
                            break;
                        }
                    }
                    if(!found)
                        System.out.println("Search failed! Account doesn't exist");
                    break;
                case 5:
                    System.out.println("See you soon...");
            }
            System.out.println();
        }while (choice != 5);
    }
}
