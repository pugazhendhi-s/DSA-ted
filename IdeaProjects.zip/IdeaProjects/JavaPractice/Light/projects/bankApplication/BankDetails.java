package projects.bankApplication;

import java.util.*;

public class BankDetails {
    private static final Scanner sc = new Scanner(System.in);
    private String name;
    private String accNo;
    private String accType;
    private double balance;
    private static int noOfAccounts = 1;
    // open account
    public void openAccount(){
        System.out.println("User : " + noOfAccounts++);
        System.out.print("Enter Account Number : ");
        accNo = sc.next();
        System.out.print("Enter Account type : ");
        accType = sc.next();
        System.out.print("Enter Name : ");
        name = sc.next();
        System.out.print("Enter balance : ");
        balance = Double.parseDouble(sc.next());
        System.out.println();
    }
    // show Account
    public void showAccount(){
        System.out.println("Name of Account Holder : " + name);
        System.out.println("Account Number : " + accNo);
        System.out.println("Account type : " + accType);
        System.out.println("Balance : " + balance);
    }
    // deposit amount
    public void deposit(){
        System.out.println("Enter the amount you want to deposit");
        double amount = Double.parseDouble(sc.next());
        balance += amount;
    }
    // withdraw amount
    public void withdrawal(){
        System.out.println("Enter the amount you want to withdraw");
        double amount = Double.parseDouble(sc.next());
        if(amount > balance)
            System.out.println("Insufficient Balance..Transaction failed..!!");
        else{
            balance -= amount;
            System.out.println(balance);
        }
    }
    // search an account number
    public boolean search(String accNo){
        if(accNo.equals(this.accNo)) {
            showAccount();
            return true;
        }
        return false;
    }
}
