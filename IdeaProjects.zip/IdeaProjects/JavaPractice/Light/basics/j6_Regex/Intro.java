package basics.j6_Regex;
import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
public class Intro {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {

//        Quantifiers();
//        basic();
        //LogicalOperator();
        //basicMatcher();
        //findMatcher();
        //Boundaries();
        //groupMatcher();
        multipleGroup();

    }

    static void Quantifiers(){
        // * zero or more amd + one or more
        String a = "Hello.*";  // Hello is followed by Zero or More char any character. eg : hell,hellq, hellquh, hell1uhg;
        String b = "Hello+";  // Hell is followed by one or More char 'o'. eg : hello, helloo, hellooo;
        String c = "Hello{2}"; // with two o characters in end . helloo
        String d = "Hello{2,4}"; // with 2,3 or 4 o characters in end .eg : helloo, hellooo, helloooo
        String e = "Helloyg1g";
        System.out.println(Pattern.matches(a, e));
    }
    static void basic(){
        String a = "http:// www.fx.com";
        String regex = "http://.*";

        boolean p = Pattern.matches(regex,a);
        System.out.println(p);

        // Regext syntax
        String b = "\\";  // match full stop character, ignore special meaning of dot (metacharacter) .
        String c = "/";  // for backslash \
        String d = "H.*llo";  // H[any character]llo => hello, hallo, hzllo [(.) any character]
        String e = "H[ae]llo"; // only a or e [ae]; [a-e] anyone from a to e (a,b...e).
        String f = "H\\]llo"; // H]llo => ] is escaped using \\.
        String g = "H[\\]\\[]llo";  // only H]llo or H[llo. 1st'[' and last '[' refers open close []

        String h = "Hi\\d"; // or "Hi[0-9]" => Hi9 or Hi2  d = digit
        String i = "Hi\\D"; // Hi is not followed by digit. D = not digit
        String j = "Hi\\w"; // or w = [A-Za-z_0-9] , W = [^A-Za-z_0-9] , ^ = not
        System.out.println(b);
        System.out.println(c);
        System.out.println(d.matches("hzllo"));
        System.out.println(e);
        System.out.println(f);
        System.out.println(g);
        System.out.println(h);
        System.out.println(i);
        System.out.println(j);



    }
    static void LogicalOperator(){
        /*String text = "Cinderella and Sleeping Beauty sat in a tree";

        Pattern pattern = Pattern.compile("[Cc][iI].*");  // String start with C or c followed by I or i eg: Cindarella
        //  ".*[Ss][Ll].*" means String start with Zero or more any characte but string must contains 'Sl' continuosly.
        Matcher matcher = pattern.matcher(text);

        System.out.println("matcher.matches() = " + matcher.matches()+", "+matcher.group());*/
        String text = "Cindarella and Sleeping Beauty sat in a tree";

        Pattern pattern = Pattern.compile(".*Ariel.*|.*Sleeping Beauty.*"); // [| = or] Arial or Sleeping Beauty.
        Matcher matcher = pattern.matcher(text);

        System.out.println("matcher.matches() = " + matcher.matches());
    }
    static void basicMatcher(){
        String text    =
                "This is the text to be searched " +
                        "for occurrences of the http:// pattern.";

        String patternString = ".*http://.*";

        Pattern pattern = Pattern.compile(patternString,Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(text);
        boolean matches = matcher.matches();
        System.out.println("matches = " + matches);
        /*String patternString = "sep";
        Pattern pattern = Pattern.compile(patternString);

        String pattern2 = pattern.pattern();
        System.out.println(pattern2);  // pattern2 = "sep";
         */
    }
    static void findMatcher(){
        String text    =
                "This is the text which is to be searched " +
                        "for occurrences of the word 'is'.";

        String patternString = "is";

        Pattern pattern = Pattern.compile(patternString);
        Matcher matcher = pattern.matcher(text);

        int count = 0;
        while(matcher.find()) {
            count++;
            System.out.println("found: " + count + " : "
                    + matcher.start() + " - " + matcher.end()+" - "+matcher.group());
        }
    }
    static void Boundaries() {
        System.out.println("Beginning of string");

        String text = "Line 1\nLine2\nLine3";

        Pattern pattern = Pattern.compile("^");
        Matcher matcher = pattern.matcher(text);

        while(matcher.find()){
            System.out.println("Found match at: "  + matcher.start() + " to " + matcher.end());
        }
        System.out.println("Beginning of string with letter");
        text = "http://jenkov.com";

        pattern = Pattern.compile("^http://");
        matcher = pattern.matcher(text);

        while(matcher.find()){
            System.out.println("Found match at: "  + matcher.start() + " to " + matcher.end());
        }
        System.out.println("End of String - $");
        text = "http://jenkov.com";

        pattern = Pattern.compile(".com$");
        matcher = pattern.matcher(text);

        while(matcher.find()){
            System.out.println("Found match at: "  + matcher.start() + " to " + matcher.end()+" "+matcher.group());
        }
        System.out.println("word boundary \b location beginning and ending of word");
        text = "Tit for Tat";

        pattern = Pattern.compile("\\bT"); // if mention anything after \\b means, it will match at the word (\\bT)
        matcher = pattern.matcher(text);

        while(matcher.find()){
            System.out.println("Found match at: "  + matcher.start() + " to " + matcher.end()+" "+matcher.group());
        }
        // Non-word boundary \B Except location beginning and ending of word*/
    }
    static void groupMatcher(){
        String text    =
                "John writes about this, and John writes about that," +
                        " and John writes about everything. "
                ;

        String patternString1 = "(John) (writes) (about)";

        Pattern pattern = Pattern.compile(patternString1);
        Matcher matcher = pattern.matcher(text);

        while(matcher.find()) {
            System.out.println("found: " + matcher.group(1)+" "+matcher.group(2) +" "+matcher.group(3));
        }
    }
    static void multipleGroup(){
        String text    =
                "John writes about this, and John Doe writes about that," +
                        " and John Wayne writes about everything."
                ;

        String patternString1 = "(John) (.+?)";

        Pattern pattern = Pattern.compile(patternString1);
        Matcher matcher = pattern.matcher(text);

        while(matcher.find()) {
            System.out.println("found: " + matcher.group(1) +
                    " "       + matcher.group(2));
        }
    }
    static void exceptionsCompile(){
        /**
         * ([A-Z])(.+)
         * [AZ[a-z](a-z)
         * batcatpat(nat
         */
        System.out.println("Enter number of testcases");
        int testcase = Integer.parseInt(sc.nextLine());
        while(testcase > 0){
            String pattern = sc.nextLine();
            try{
                Pattern.compile(pattern);
                System.out.println("Valid");
            }
            catch (Exception e){
                System.out.println("InValid");
            }
            testcase--;
        }
    }

}
