package basics.j6_Regex;
import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
public class Problems {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        duplicatewordsByRegex();
    }
    static void duplicatewordsByRegex(){
        String regex = "\\b(\\w+)(?:\\W\\1\\b)+";
        Pattern p = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);

        Scanner in = new Scanner(System.in);
        System.out.println("Enter no of duplicate sentences");
        int numSentences = Integer.parseInt(in.nextLine());

        while (numSentences-- > 0) {
            String input = in.nextLine();

            Matcher m = p.matcher(input);

            // Check for subsequences of input that match the compiled pattern
            while (m.find()) {

                System.out.println(m.group()+"\n"+m.group(1)+"\n"+m.start()+" "+m.end());
                input = input.replaceAll(m.group(), m.group(1));

            }

            // Prints the modified sentence.
            System.out.println(input);
        }
    }
    static void validIp(){
        String ip = sc.nextLine();
        String num = "([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])";
        String regex = num+"\\."+num+"\\."+num+"\\."+num;
        System.out.println(ip.matches(regex));
        /*
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(ip);
        System.out.println(matcher.matches());
        */
    }
    static void checkVowels(){
        String s = "boOk";
        for (char ch: s.toCharArray()) {
            if(Pattern.matches("[aeiouAEIOU]",String.valueOf(ch))){
                System.out.println("Contains Vowels");
                return;
            }
        }
        System.out.println("No Vowels");
    }
    static void example1(){
        String text = "John went for a walk, and John fell down, and John hurt his knee.";
        String regex = "John.*?";
        boolean pattern = Pattern.matches(regex,text);
        System.out.println(pattern);
    }
}
