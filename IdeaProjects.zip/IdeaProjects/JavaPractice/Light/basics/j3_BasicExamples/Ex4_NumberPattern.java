package basics.j3_BasicExamples;

import java.util.Scanner;

public class Ex4_NumberPattern {
    static Scanner sc = new Scanner(System.in);

    public static void main() {

    }
    static void pattern2(){
        /** output
            1 0 1 0 1
            0 1 0 1 0
            1 0 1 0 1
            0 1 0 1 0
            1 0 1 0 1

         */
        System.out.println("Enter Size...");
        int size = sc.nextInt();
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                if(i%2 != 0 && j%2 != 0 || i%2 == 0 && j%2 == 0)
                    System.out.print(1+" ");
                else
                    System.out.print(0+" ");
            }
            System.out.println();
        }
    }
    static void pattern1(){
        System.out.println("Enter Size..Unknown Pattern...");
        int size = sc.nextInt();
        for (int i = 1; i <= size; i++) {
            for (int j = 1; j <= size; j++) {
                if(i < size-j)
                    System.out.print(1+" ");
                else
                    System.out.print(i+" ");
            }
            System.out.println();
        }
    }
    static void odd1(){
        System.out.println("Odd value as One");
        int size = sc.nextInt();
        for (int i = 1; i <= size; i++) {
            for (int j = 1; j <= i; j++) {
                if(j % 2 == 0)
                    System.out.print(0+" ");
                else
                    System.out.print(1+" ");
            }
            System.out.println();
        }
    }
    static void sandClock(){
        System.out.println("Sand Clock Pattern Number....");
        int size = sc.nextInt();
        int count = 0;
        for (int i = 1; i < 2*size; i++) {
            count = i;
            int flag = 0;
            for (int j = 1; j <= size; j++) {
                if(i <= size && j < i)
                    System.out.print(" ");
                else if (i <= size)
                    System.out.print((count++)+" ");
                else if (j < size - i%size)
                    System.out.print(" ");
                else{
                    count = size + flag - i%size;
                    System.out.print(count+" ");
                    flag++;
                }
            }
            System.out.println();
        }
    }
    static void sandGlass(){
        System.out.println("Sandglass Number Pattern..");
        int size = sc.nextInt();
        int count = 0;
        for (int i = 1; i < 2*size; i++) {
            count = i;
            int flag = 0;
            for (int j = 1; j <= size;j++) {
                if(i <= size && j < i )
                    System.out.print("  ");
                else if(i <= size)
                    System.out.print((count++)+" ");
                else if (j < size - i%size)
                    System.out.print("  ");
                else {
                    count = size + (flag)-(i%size);
                    System.out.print((count) + " ");
                    flag++;
                }
            }
            System.out.println();
        }
    }
    static void halfDiamondNumber() {
        System.out.println("Half Diamond Number Pattern");
        int size = sc.nextInt();
        int count = 1;
        for (int i = 1; i < 2 * size; i++) {
            count = 1;
            if (i <= size) {
                for (int j = 1; j <= i; j++, count++)
                    System.out.print(count + " ");
            }
            else {
                for (int j = 1; j <= size - i%size; j++,count++) {
                    System.out.print(count+ " ");
                }
            }
            System.out.println();
        }
    }

    static void verticalIncremented(){
        System.out.println("Vertical Incremented Number Pattern...");
        int size = sc.nextInt();
        int count = 0;

        for (int i = 1; i <= size; i++) {
            count = i;
            for (int j = 1; j <= i; j++) {
                System.out.print(count+" ");
                count += size-j;
            }
            System.out.println();
        }
    }
    static void incInvertedTriangle(){
        System.out.println("Incremented Inverter Triangle");
        int size = sc.nextInt();
        int count = (size * 2)-1;
        for (int i = 0; i < size; i++,count--) {
            for (int j = 0; j < size-i; j++) {
                System.out.print(count+" ");
            }
            System.out.println();
        }
    }
    static void invertedRightAngledTriangle(){
        System.out.println("Inverted Right Angled Triangle");
        int size = sc.nextInt();
        int count = size * (size+1)/2;  // sum of n natural number = n*(n+1)/2
        for (int i = 0; i < size; i++) {
            for (int j = 0; j <= i ; j++) {
                System.out.print(count-- +" ");
            }
            System.out.println();
        }
    }
    static void internalVarsityNumber(){
        System.out.println("Internal Varsity Number...");
        int size = sc.nextInt();
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                if(i == 0 || j == 0 || i == size-1 || j == size-1)
                    System.out.print(size+" ");
                else
                    System.out.print(i+" ");
            }
            System.out.println();
        }
    }
    static void basicSquareIncrement(){
        System.out.println("Sqaure Increment with number...");
        int size = sc.nextInt();
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                System.out.print(i+" ");
            }
            System.out.println();
        }
    }
    static void snakePattern(){
        System.out.println("Snake Pattern ..");
        int size = sc.nextInt();
        int count = 10;
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size-i; j++) {
                System.out.print("  ");
            }
            if(i%2 != 0) {
                count += size-1;
                for (int j = 0; j < size; j++) {
                    System.out.print(count--+" ");
                }

                count += size+1;
            }
            else {
                for (int j = 0; j < size; j++) {
                    System.out.print((count++) + " ");
                }
            }
            System.out.println();
        }
    }
}
