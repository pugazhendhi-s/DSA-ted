package basics.j3_BasicExamples;

import java.util.Scanner;

public class Ex2_Conversion {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        Power_Recursion();
        Reverse_sentence_recursion();
        HexaTODeci();
        DeciTOOcta();
        DeciToBinary();
        GCDRecursion();
         BinaryToDeci();
    }
    static void HexaTODeci(){
        System.out.println("Enter HexaDecimal Value ");
        String hexaString = "0123456789ABCDEF";
        String hexanum = sc.nextLine().toUpperCase();
        int result = 0;
        for (int i = 0; i < hexanum.length(); i++) {
             char ch = hexanum.charAt(i);
             int a = hexaString.indexOf(ch);
             System.out.println(a);  // a refers value of index pf char in hexaString if ch = F => a = 15, F index is 15
             result = result * 16 + a;
        }
        System.out.println(hexanum + " "+result);
        System.out.println("Using Library");
        String hex = sc.nextLine();
        int deci = Integer.parseInt(hex,16);
        System.out.println(hex+" = "+deci);

    }
    static void DeciTOOcta(){
        System.out.println("Enter Deci Value ");
        int num = sc.nextInt();
        int temp = num;
        int result = 0;
        int i = 1;
        while(temp != 0){
            int rem = temp % 8;
            result += (rem * i);
            temp /= 8;
            i *= 10;
        }
        System.out.printf("%d = %d", num, result);
        System.out.println("\nUsing Library");
        int decimal = 333;
        String Octa = Integer.toOctalString(decimal);
        System.out.println(decimal+" = "+Octa);
    }
    static void DeciToBinary(){
        System.out.println("Enter Decimal Value ");
        int num = sc.nextInt();
        int temp = num;
        int result = 0;
        int i = 1;
        while(temp != 0){
            int rem = temp % 2;
            result += (rem * i);
            temp /= 2;
            i *= 10;
        }
        System.out.printf("%d = %d", num, result);
        System.out.println("\nUsing Library");
        int decimal = 333;
        String binary = Integer.toBinaryString(decimal);
        System.out.println(decimal+" = "+binary);
    }
    static void BinaryToDeci(){
        System.out.println("Enter Binary Value ");
        long num = sc.nextInt();
        long temp = num;
        int result = 0;
        int exponent = 0;
        while(num != 0){
            result += ((num % 10) * Math.pow(2,exponent++));
            num /= 10;
        }
        System.out.printf("Decimal value of %d is %d", temp, result);
        // Using Library
        System.out.println("\nBinary to Decimal Conversion using library");
        String BinaryNum = "1111";
        int DecimalNum = Integer.parseInt(BinaryNum,2);
        System.out.println(BinaryNum + " = "+DecimalNum);
    }
    static void Power_Recursion(){
        System.out.println("Enter the base and exponent to find power of base");
        int base = sc.nextInt();
        int exponent = sc.nextInt();
        int power = Power_RecursionFunc(base, exponent);
        System.out.println(base + " ^ " + exponent + " = " +power);
    }
    static int Power_RecursionFunc(int base, int exponent){
        if(exponent == 0)
            return 1;
        return base * Power_RecursionFunc(base, exponent - 1);
    }

    static void Reverse_sentence_recursion(){
        System.out.println("Enter the sentence to reverse it using Recursion");
        String input = sc.nextLine();
        String reversed = stringRecursion(input);
        System.out.println(input + " = "+reversed);
    }
    static String stringRecursion(String input){
        if(input.isEmpty())
            return input;
        return  stringRecursion(input.substring(1))+ input.charAt(0) ;

    }

    static void GCDRecursion(){            // GCD or HCF
        System.out.println("Enter number to find GCD");
        int a = sc.nextInt();
        int b = sc.nextInt();
        int gcd = GCDRecursionFunc(a,b);
        System.out.println("GCD : "+gcd);
    }    // a = 16 , b = 72
    static int GCDRecursionFunc(int a, int b){
        if(b != 0)
            return GCDRecursionFunc(b, a%b);
        else
            return a;
    }
}
