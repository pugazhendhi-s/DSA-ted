package basics.j3_BasicExamples;

import java.util.*;

public class Ex1_CommonProblems {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        Number_canbe_Expressed_as_SumOfTwoPrimeNumbers();
        //FactorsofNumber();
        //PrimeCheckInRange();
        //ArmStrongNumberInRange();
        //PrimeNumber();
        //Palindrome();
        //Pow();
        //ReverseNumber();
        //CountDigits();
        //Alphabets();
        //GCDandLCM();
        //FibonacciSeries();
        //IsVowel();
        //FindRoots();
        //LeapYear();
        //Sumofnatural();
        //Factorial();
    }
    static void Number_canbe_Expressed_as_SumOfTwoPrimeNumbers(){
        System.out.println("Enter number to sum of prime numbers");
        int num = sc.nextInt();
        int i = 1; boolean flag = false;
        while(i++ <= num/2){
            if(!PrimeFunction(i)){
                if(!PrimeFunction(num - i)){
                    System.out.printf("%d = %d + %d\n", num, i, num-i);
                    flag = true;
                }
            }
        }
        if(!flag)
            System.out.printf("%d number can't be expressed as sum of two prime numbers.");
    }
    static void FactorsofNumber(){
        System.out.println("Enter number to find factors");
        int num = sc.nextInt();
        int i = 0;
        while(i++ <= num){
            if(num % i == 0)
                System.out.print(i+" ");
        }
    }
    static void PrimeCheckInRange(){
        System.out.println("Enter Range to find all Prime Number");
        int start = sc.nextInt();
        int end = sc.nextInt();
        while (start++ < end)
            if(!PrimeFunction(start))
                System.out.print(start+" ");
    }
    static boolean PrimeFunction(int num){
        boolean flag = false;
        for (int i = 2; i <= num/2; i++) {
            if (num % i == 0) {
                return true;
            }
        }
        return false;
    }
    static void ArmStrongNumberInRange(){
        System.out.println("Enter Range to find all Armstrong Number");
        int start = sc.nextInt();
        int end = sc.nextInt();
        for (int i = start; i <= end; i++) {
             if(ArmstrongFunction(i))
                 System.out.print(i+" ");
        }
    }
    static boolean ArmstrongFunction(int num){
        boolean flag = false;
        int count = 0;
        int temp = num;
        while(temp != 0){
            temp /= 10;
            count ++;
        }
        temp = num;
        int sum = 0;
        while(temp != 0){
            int rem = temp % 10;
            sum += Math.pow(rem,count);
            temp /= 10;
        }
        if(num == sum)
            return true;
        return false;
    }
    static void PrimeNumber(){
        System.out.println("Enter number to check Prime ");
        int num = sc.nextInt();
        boolean flag = false;
        for (int i = 2; i <= num/2; i++) {
            if (num % i == 0) {
                flag = true;
                break;
            }
        }
        if(!flag)
            System.out.println("Prime Number");
        else
            System.out.println("Not a Prime Number");
    }
    static void Palindrome(){
        System.out.println("Enter string to check form Palindrome");
        String a = sc.nextLine();
        String reverse = "";
        for (int i = 0; i<a.length(); i++) {
            reverse = a.charAt(i)+reverse;
        }
        System.out.println((a.equalsIgnoreCase(reverse)) ? "Palindrome" : "Not a Palindrome");
    }
    static void Pow(){
        System.out.println("Find Power of number");   // Math.pow(base,power)
        int base = sc.nextInt();
        int exponent = sc.nextInt();
        int result = 1;
        while(exponent-- != 0){
            result *= base;
        }
        System.out.println("Output : "+ result);
    }
    static void ReverseNumber(){
        System.out.print("Enter number : ");
        int num = sc.nextInt();
        int reverse = 0;
        while(num != 0){
            int remainder = num % 10;
            reverse = (reverse * 10) + remainder;
            num /= 10;
        }
        System.out.printf("Reverse is %d",reverse);
    }
    static void CountDigits(){
        System.out.print("Enter number : ");
        int num = sc.nextInt();
        int temp = num;
        int count = 0;
        while(num != 0){
            num /= 10;
            count ++;
        }
        System.out.printf("No of Digits in %d is %d",temp, count);
    }
    static void Alphabets(){
        int a = 65, b = 90;
        for (int i = a; i <= b; i++) {
            System.out.print((char) i+" ");
        }
        System.out.println();
        char ch;
        for (ch = 'a'; ch <= 'z'; ch++) {
            System.out.print(ch+" ");
        }
    }
    static int gcd(int a, int b){
        if(b == 0)
            return a;
        return gcd(b,a%b);
    }
    static void GCDandLCM(){
        System.out.println("Enter numbers to find GCD and LCM");
        int a = sc.nextInt();
        int b = sc.nextInt();
        int temp1 = a;
        int temp2 = b;
        System.out.println(gcd(a,b));
        /* int i = (a > b) ? b : a;
        while (i-- > 0){
            if(a % i == 0 && b % i == 0) {
                System.out.printf("GCD of %d and %d is %d", a, b, i);
                break;
            }
        }
        or */
        a = (a > 0) ? a : -a;
        b = (b > 0) ? b : -b;
        while(a != b){
            if(a > b)
                a -= b;
            else
                b -= a;
        }
        int gcd = a;
        int lcm = temp1 * temp2/gcd;
        System.out.printf("GCD : %d, LCM : %d",gcd,lcm);
        // Find LCM uniquely

        lcm = (temp1 > temp2) ? temp1 : temp2;
        while(true){
            if(lcm % temp1 == 0 && lcm % temp2 == 0)
                break;
            lcm++;
        }
        System.out.printf("\tLCM : %d",lcm);
    }
    static void FibonacciSeries(){
        System.out.print("Length of Series : ");
        int num = sc.nextInt();
        int first = 0; int second = 1;
        int i = 1;
        while(i++ <= num){
            System.out.print(first+" ");
            int next = first + second;
            first = second;
            second = next;

        }
    }
    static void IsVowel() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter : ");
        char ch = sc.nextLine().charAt(0);
        String match = "aeiouAEIOU";
        System.out.println(match.indexOf(ch) == -1 ? "Consonant" : "Vowel");
    }
    static void FindRoots(){
        // ax^2+ bX + c = 0
       // x = (-b +- (b^2 - 4ac))

        double a = 2.3; double b = 4; double c = 5.6;
        double root1, root2;
        double discriminant = (b * b) - (4 * a * c);

        if( discriminant < 0){
            System.out.println("Roots are complex");
            double real = -b/(2 * a);
            double imaginary = Math.sqrt(-discriminant)/(2*a);
            System.out.printf("root1 = %.2f+%.2fi", real, imaginary);
            System.out.printf("\nroot2 = %.2f-%.2fi", real, imaginary);
        }
        else if(discriminant == 0){
            System.out.println("Roots are real and same");
            root1 = root2 = -b/(2 * a);
            System.out.printf("root1 = root2 = %.2f", root1);
        }
        else {
            System.out.println("Roots are real and different");
            root1  = (- b - Math.sqrt(discriminant))/(2 * a);
            root2  = (- b + Math.sqrt(discriminant))/(2 * a);
            System.out.printf("root1 = %.2f and root2 = %.2f", root1, root2);
        }

    }
    static void LeapYear(){
        System.out.print("Enter year : ");
        int year = sc.nextInt();
        if(year % 400 == 0 || year % 100 != 0 && year % 4 == 0)
            System.out.printf("Leap year : %d ", year);
        else
            System.out.printf("Not a Leap year : %d", year);
    }
    static void Sumofnatural(){
        int a = sc.nextInt();
        if(a > 0){
            int output = (a * (a + 1))/2;
            System.out.printf("Output : %d",output);
        }
        else
            System.out.printf("%d is not a Natural number",a);
    }
    static void Factorial(){
        System.out.print("Enter No to find factorial : ");
        int n = sc.nextInt();
        long factorial = MultiplyNumber(n);
        /* int result = 1;
        int temp = n;
        while(temp > 0){
            result *= temp;
            temp--;
        } */
        System.out.printf("Factorial of %d is %d",n, factorial);
        // using recursion
    }
    static long MultiplyNumber(int num){
        if( num >= 1)
            return num * MultiplyNumber(num - 1);
        else
            return 1;
    }
    
}
