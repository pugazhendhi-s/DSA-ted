package basics.j3_BasicExamples;

import java.util.Scanner;

public class Ex3_StarPatterns {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {

    }
    public static void sandGlass(){
        System.out.println("SandGlass Pattern.......");
        int size = sc.nextInt();

        for (int i = 1; i <= 2*size; i++){
            for (int j = 1; j <= 2*size; j++) {
                if(i == 1 || i == 2*size || j == 1 || j == 2*size)
                    System.out.print("* ");
                else if (j <= size-i+1  || j >= size+i)
                    System.out.print("* ");
                else if (i == size || i == size+1 ) {
                    System.out.print("  ");

                } else if (i > size ){
                    if(j <= i-size || j >= (2*size)+1-i%size)
                        System.out.print("* ");
                    else
                        System.out.print("  ");
                } else
                    System.out.print("  ");
            }
            System.out.println();
        }

    }
    static void halfDiamond(){
        System.out.println("Half Diamond...");
        int size = sc.nextInt();

        for (int i = 0; i < size; i++) {
            for (int j = 0; j <= i; j++) {
                if(j == 0 || j == i || i == size-1 )
                    System.out.print("* ");
                else
                    System.out.print("  ");
            }
            System.out.println();
        }
        for (int i = 0; i < size-1; i++) {
            for (int j = 0; j < size-1-i; j++) {
                if(j == 0 || j == size-i-2)
                    System.out.print("* ");
                else
                    System.out.print("  ");
            }
            System.out.println();
        }
    }
    static void hollowPyramid(){
        System.out.println("Hollow Pyramid");
        int size = sc.nextInt();

        for (int i = 1; i <= size; i++) {
            for (int j = 1; j <= size-i; j++) {
                System.out.print("- ");
            }
            for (int j = 1; j <= 2*i -1; j++) {
                if(j == 1 || j == 2*i -1 || i == size)
                    System.out.print("* ");
                else
                    System.out.print("  ");
            }
            System.out.println();
        }
    }
    static void rightAngledTriangleHollow(){
        System.out.println("Right Angled Triangle...");
        int size = sc.nextInt();

        for (int i = 0; i < size; i++) {
            for (int j = 0; j <= i ; j++) {
                if(j == 0 || j == i || i == size-1)
                    System.out.print("* ");
                else
                    System.out.print("  ");
            }
            System.out.println();
        }
    }
    static void hollowDiamond(){
        System.out.println("HollowDiamond..");
        int rows = sc.nextInt();

        for (int i = 0; i < rows; i++) {
            for (int j = 1; j < rows-i; j++) {
                System.out.print("  ");
            }
            for (int j = 0; j <= i*2; j++) {
                if(j == 0 || j == i*2 || j == i) {
                    System.out.print("* ");
                }
                else{
                    System.out.print("  ");
                }
            }
            for (int j = 1; j < rows-i; j++) {
                System.out.print("  ");
            }
            System.out.println();
        }

        for (int i = 0; i < rows-1; i++) {
            for (int j = 1; j <= i+1; j++) {
                System.out.print("  ");
            }
            for (int j = 0; j < 2*rows - 3 - 2*i; j++) {
                if(j == 0 || j == 2*rows -4 - 2*i || j == rows - 2 - i)
                    System.out.print("* ");
                else
                    System.out.print("  ");
            }
            for (int j = 1; j <= i+1; j++) {
                System.out.print("  ");
            }
            System.out.println();
        }
    }
    static void parallelogram(){
        System.out.println("Forward Parallelogram Printing");
        int length = sc.nextInt();
        int breadth = sc.nextInt();

        for (int i = 1; i <= length; i++) {
            for (int j = 1; j <= i; j++) {
                System.out.print("- ");
            }
            for (int j = 1; j <= breadth; j++) {
                System.out.print("* ");
            }
            System.out.println();
        }
        System.out.println("Backward Parallelogram printing....");
        int len = sc.nextInt();
        int bdth = sc.nextInt();
        for (int i = 0; i < len; i++) {
            for (int j = 0; j < len-i; j++)
                System.out.print("- ");
            for (int j = 0; j < bdth; j++) {
                System.out.print("* ");
            }
            System.out.println();
        }
    }
    static void Square(){
        System.out.println("Print Square");
        int length = sc.nextInt();
        for (int i = 0; i < length; i++) {
            for (int j = 0; j < length; j++)
                System.out.print("* ");
            System.out.println();
        }
    }
    static void HollowRectangle(){
        System.out.println("Enter length to hollow Rectangle");
        int length = sc.nextInt();
        int breadth = sc.nextInt();
        for (int i = 0; i < length; i++) {
            for (int j = 0; j < breadth; j++) {
                if(i == 0 || j == 0 || i == length-1 || j == breadth-1)
                    System.out.print("* ");
                else
                    System.out.print("  ");
            }
            System.out.println();
        }
    }

}
