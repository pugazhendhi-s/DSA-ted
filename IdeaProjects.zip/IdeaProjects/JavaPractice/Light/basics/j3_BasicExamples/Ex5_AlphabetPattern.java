package basics.j3_BasicExamples;

public class Ex5_AlphabetPattern {
    public static void main(String[] args) {
        invertedVertical();
    }
    static void pattern5(){
        int n = 5;
        for (int i = 1; i <= n; i++) {
            int a = 96 + i;
            for (int j = 1; j <= n+1; j++) {
                if(j <= i)
                    System.out.print(i+" ");
                else
                    System.out.print((char) a+" ");
            }
            System.out.println();
        }
    }
    static void normalVertical(){
        /**
         * A J K T U
         * B I L S V
         * C H M R W
         * D G N Q X
         * E F O P Y
         */
        int n = 5; int a = 65;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if(j % 2 == 0) {
                    int temp = (j*n)+ i;
                    System.out.print((char) (a+temp) + " ");
                }
                else{
                    int temp = (j*n)+(n-i-1);
                    System.out.print( (char) (a+temp)+" ");
                }
            }
            System.out.println();
        }
    }
    static void invertedVertical(){
        /*
         * A
         * B I
         * C H J
         * D G K N
         * E F L M O
         */
        int n = 5;
        int a = 65;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j <= i; j++) {
                if(j % 2 == 0) {
                    int tot = j*n + i;
                    int temp =  tot -j -(j-1) * j/2;
                    System.out.print((char) (a+temp) +" ");
                }
                else{
                    int tot = j*n + n -1 -i;
                    int temp =  tot -((j-1) * j/2);
                    System.out.print((char) (a+temp)+ " ");
                }
            }
            System.out.println();
        }
    }

    static void sumOfNatural(){
        int n = 4;
        int a = 65+ n * (n+1)/2;
        for (int i = 1; i <= n; i++) {
            a = a - i;
            for (int j = 1; j <= i; j++) {
                System.out.print((char) (a+j-1) +" ");
            }
            System.out.println();
        }
    }
    static void sandGlass(){
        /**
         * ABCDEFEDCBA
         * ABCDE EDCBA
         * ABCD   DCBA
         * ABC     CBA
         * AB       BA
         * A         A
         * AB       BA
         * ABC     CBA
         * ABCD   DCBA
         * ABCDE EDCBA
         * ABCDEFEDCBA

         */
        int n = 5;int a = 65;
        for (int i = 0; i <= 5; i++) {
            for (int j = 0; j <= n-i; j++) {
                System.out.print((char) (a+j));
            }
            for (int k = 0; k < 2*i-1; k++) {
                System.out.print(" ");
            }
            for (int l = n-i; l >= 0; l--) {
                if(l != n)
                    System.out.print((char) (a+l));
            }
            System.out.println();
        }
        for (int i = 1; i <= n; i++) {
            for (int j = 0; j <= i; j++) {
                System.out.print((char) (a+j));
            }
            for (int k = i; k < 2*n-i-1; k++) {
                System.out.print(" ");
            }
            for (int l = 0; l <= i; l++) {
                int temp = i-l;
                if(i == n)
                    temp = i-l-1;
                if(l != n)
                    System.out.print((char) (a+temp));
            }
            System.out.println();
        }
    }
    static void pattern4(){
        /*
        ABCDEFEDCBA
        ABCDE EDCBA
        ABCD   DCBA
        ABC     CBA
        AB       BA
        A         A
         */
        int n = 6;
        for (int i = 1; i <= n; i++) {
            int a = 65;int decrement = n-2; int  d = 1;
            for (int j = 1; j < 2*n; j++) {

                if(j <= n-i+1){
                    System.out.print((char) a++ +" ");
                }
                if(i == 1 && j > n){
                    a = 65+decrement--;
                    System.out.print((char) a +" ");
                }
                else if (j > n-i+1  && j < n+i-1 ) {
                    System.out.print("  ");
                } else if (i > 1 && j >= n+i-1) {
                    System.out.print((char) (a-d++)+" ");
                }
            }
            System.out.println();
        }

    }
    static void aBCDTraverse(){
        /*ABCDE
        BCDEF
        CDEFG
        DEFGH
        EFGHI*/
        int n = 5;
        for (int i = 0; i < n; i++) {
            int a = 65+i;
            for (int j = 0; j < n; j++,a++) {
                System.out.print((char) a+" ");
            }
            System.out.println();
        }
    }
    static void pattern3(){
        int n = 5;int a = 65; int countAlphabet = 1, rowcount = 1;
        for (int i = 1; i <= n; i++) {
            int temp = rowcount + countAlphabet -1;
            for (int j = 1; j <= i; j++) {
                if(i % 2 != 0){
                    System.out.print((char) (a + countAlphabet - 1)+" ");
                    countAlphabet++;
                }
                else{
                    System.out.print((char) (a+temp-1) + " ");
                    temp--; countAlphabet++;
                }
            }
            rowcount++;
            System.out.println();
        }
    }

    static void stringPattern(){
        String str = "LOVEIsLust";
        int n = str.length();
        for (int i = 1; i <= n; i++) {
            char c = str.charAt(i-1);
            for (int j = 1; j <= n-i; j++) {
                System.out.print("  ");
            }
            for (int j = 1; j < 2*i; j++) {
                System.out.print(c+" ");
            }
            System.out.println();
        }
    }
    static void UnknownPattern2(){
        /*
         * A A A A A A
         * A A A A B B
         * A A A C C C
         * A A D D D D
         * A E E E E E
         * F F F F F F
          */
        int n = 6;
        for (int i = 1; i <= n; i++) {
            int a = 65;
            for (int j = 1; j <= n; j++) {
                if(j < n-i+1)
                    System.out.print((char) a+" ");
                else {
                    a = 65 + i - 1;
                    System.out.print((char) a+" ");
                }
            }
            System.out.println();
        }
    }
    static void InvertedTriangle(){
        /*
         A B C D E F
          A B C D E
           A B C D
            A B C
             A B
              A
         */
        System.out.println("Inverted Triangle");
        int n = 6;
        for (int i = 1; i <= 6; i++) {
            int a = 65;
            for (int j = 1; j <= 6; j++) {
                if(j < i)
                    System.out.print("  ");
                else
                    System.out.print((char) a++ +" ");
            }
            System.out.println();
        }
    }
    static void UnknownPattern1(){
        /*
        A
        A B A
        A B C B A
        A B C D C B A
        A B C D E D C B A
        A B C D E F E D C B A
        */
        int n = 6;
        for (int i = 0; i < n; i++) {
            int a = 65;
            for (int j = 0; j <= i; j++,a++) {
                System.out.print((char) a+" ");
            }
            a = 65+i-1;
            for (int j = 0; j < i; j++,a--) {
                System.out.print((char) a+" ");
            }
            System.out.println();
        }
    }
    static void Vertical(){
        int n = 5;
        for (int i = 1; i <= n; i++) {
            int a = (int) 'A'+i-1;
            for (int j = 1; j <=i ; j++) {
                System.out.print((char) a+" ");
                a = a+n-j;
            }
            System.out.println();
        }
    }
    static void EquilateralTriangle(){
        System.out.println("** Printing the pattern... **");
        for (int i = 1; i <= 7; i++) {
            int alphabet = 65;
            for (int j = 7; j > i; j--)
                System.out.print(" ");

            int temp = 1;
            for (int k = 1; k <= i; k++){
                System.out.print((char) (alphabet - 1 + temp) + " ");
                temp = temp * (i - k) / (k);
            }
            System.out.println();
        }
    }
    static void SummationSymbol(){
        int n = 5;
        for (int i = 0; i < 2*n; i++) {
            int a = (int)'A'+n-1-i;
            int b = (int)'A'+i%n;
            for (int j = 0; j < n; j++,a--,b--) {
                if(i < n && j < n-i){
                    System.out.print((char) a+" ");
                }
                else if( i >= n && j <= i%n){
                    System.out.print((char) b+" ");
                }
            }
            System.out.println();
        }
    }
    static void RightHalfDiamond(){
        int n = 5;
        for (int i = 0; i < 2*n+1; i++) {
            int a = (int) 'A';
            for (int j = 0; j <= n; j++,a++) {
                if(i == 0 || i == 2*n) {
                    System.out.print((char) a); break;
                }
                else if(i <= n && j <= i){
                    System.out.print((char) a+" ");
                }
                else if(i > n && j <= n-i%n){
                    System.out.print((char) a+" ");
                }
            }
            System.out.println();
        }
    }
    static void RightAngled(){
        int n = 5; int a = (int) 'A';
        for (int i = 0; i < n; i++,a++) {
            for (int j = 0; j <= i; j++) {
                System.out.print((char) a);
            }
            System.out.println();
        }
    }
}
