package basics.j1_Basics;

import java.util.Random;

public class Ex5_RandomNumber {
    public static void main(String[] args) {
        variableArgument();
        randomNumber();
    }
    static void variableArgument(){
        System.out.println( sum(4,5,6,7,82,3,5));
    }
    static int sum(int...numbers){ // lot of numbers we can pass
        int tot = 0;
        for (int i: numbers) {
            tot += i;
        }
        return tot;
    }
    static void randomNumber(){
        Random random = new Random();
        for (int i = 1; i <= 5; i++) {
            System.out.println(random.nextInt(5)+1);
        }
    }
}
