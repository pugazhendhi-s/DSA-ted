package basics.j1_Basics;
import java.util.Scanner;
public class Ex3_if_loops_jump {
    /*
        Decision Making statements
            if statements
            switch statement
        Loop statements
            do while loop
            while loop
            for loop
            for-each loop
        Jump statements
            break statement
            continue statement
     */
    public static void main(String[] args) {
        // ifElse();
        // switchCase();
        // forLoop();
         doWhile();
        // breakLoop();
        //continueLoop();
    }
    static void ifElse(){
        int a = 10, b = 20, c = 30;
        if(a > b && a > c)
            System.out.println(a+" is Greater");
        else if (b > a && b > c)
            System.out.println(b+" is Greater");
        else
            System.out.println(c+" is Greater");
    }
    static void switchCase(){
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Choice : ");
        int a = sc.nextInt();
        switch (a){
            case 1:
                System.out.println("Case 1 executed");
                break;
            case 3:
                System.out.println("Case 2 executed");
                break;
            default:
                System.out.println("All cases are executed");
        }
    }
    static void forLoop(){
        int a = 10;
        for (int i=0; i<a; i++){
            System.out.print(i+" ");
        }
        System.out.println();
        int[] b = {1,2,3,4,5};
        for (int i : b){
            System.out.print(i+" ");
        }
    }
    static void doWhile(){
        int a = 10;
        int i = 0;
        System.out.println("While");
        while (i < a){
            System.out.print(i+" ");
            i++;
        }
        System.out.println("\nDo While");
        i = 0;
        do{
            System.out.print(i+" ");
            i++;
        }while (i < a);
    }
    static void breakLoop(){
        int a = 4;
        aa:
        for (int i = 0; i < a; i++){
            bb:
            for (int j = 0; j < a; j++) {
                if(i==2 && j==2)
                    break aa;
                System.out.println(i+" "+j);
            }
        }
    }
    static void continueLoop(){
        aa:
        for (int i = 0; i <= 3; i++){
           bb:
           for (int j = 0; j <= 3; j++) {
               if(i == 2 && j == 2)
                   continue aa;
               System.out.println(i+" "+j);
           }
        }
        //\u000d System.out.println("T E D");
    }
}

