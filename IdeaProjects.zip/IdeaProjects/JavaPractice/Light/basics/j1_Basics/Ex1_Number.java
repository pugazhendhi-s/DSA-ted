package basics.j1_Basics;

public class Ex1_Number {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        // Class Loader
        Class c = Ex1_Number.class;
        System.out.println(c.getClassLoader());

        // Widening
        int a = 10;
        float b = a;
        System.out.println(b);

        // Type Casting
        float d = 10.6f;
        int e = (int)d;
        System.out.println(e);

        // Overflow
        int f = 130;
        byte g = (byte) f;
        System.out.println(g);

        // Adding Lower type
        byte h = 10;
        byte j = 20;
        // byte k = h + j; Error a + b is int
        System.out.println(h+j);
        Byte k = (byte)(h+j);
        System.out.println(k);
    }
}