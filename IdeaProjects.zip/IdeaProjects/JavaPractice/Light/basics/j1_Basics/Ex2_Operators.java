package basics.j1_Basics;

public class Ex2_Operators {
    // Primitive - boolean, char, byte(-128 to 127), short, int, long, float, doubles
    // Non - Primitive - Arrays, String, class, Interfaces

    // Operators
    public static void main(String... args) {
         Urinary();
        Arithmetic();
        Shift();
        logicBitwise();
        Ternary();
       Ex2_Operators d = new Ex2_Operators();
       d.Assignment();
    }
    static void Urinary(){
        System.out.println("urinary");
        int a = 10; int b = 10;
        System.out.println(a++ + ++a);
        System.out.println(b++ + --b);
        int c = 10; int d = -10;
        System.out.println(~c);
        System.out.println(~d);
        boolean e = true;
        System.out.println(!e);
    }
    static void Arithmetic(){
        System.out.println("Arithematic");
        int a = 10, b = 20;
        System.out.println(a+b);
        System.out.println(a-b);
        System.out.println(a*b);
        System.out.println(b/a);
        System.out.println(a%b);
    }
    static void Shift(){
        System.out.println("Shift");
        int a = 10, b = 20;
        // Right Shift
        System.out.println(a<<2);
        System.out.println(b<<3); // 20*(2^3) = 20*8 = 160
        // Left Shift
        int c = 10, d = 20;
        System.out.println(c>>2); // 10/(2^2) = 10/4 = 2
        System.out.println(d>>4); // 10/(2^4) = 20/16 = 1 quotient
    }
    static void logicBitwise(){
        System.out.println("Bitwise");
        int a = 10, b = 20;
        System.out.println(a>b & b>a);
        System.out.println(a>b | b>a); //bitwise or
        // difference between logical and bitwise
        System.out.println(a>b && ++a<b); // && doesn't check 2 condition if 1st condition false means
        System.out.println("Logical : "+a);
        System.out.println(a>b & ++a<b);   // && check 2 condition even 1st condition false means
        System.out.println("Bitwise : "+a);
    }
    static void Ternary(){
        System.out.println("Ternary");
        int a = 10, b = 20;
        int min = (a>b)? b:a; // (a<b) ? a:a;
        System.out.println(min);
    }
    void Assignment(){
        System.out.println("Assignment");
        int a = 10, b = 20;
        System.out.println("Sum : "+ (a+=b) +", Sub : "+ (a-=b)+", Multi : "+(a*=b)+", Divide : "+(a/=b)+", Modulo : "+(a%=b));
        short c = 10, d = 10;
        c = (short)(c+d);
        System.out.println(c);

    }
}
