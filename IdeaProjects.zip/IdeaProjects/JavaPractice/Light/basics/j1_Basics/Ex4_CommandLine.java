package basics.j1_Basics;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

public class Ex4_CommandLine {
    public static void main(String... args) throws IOException {
        bufferReader();

        if(args.length > 0){
            for (String s: args) {
                System.out.println(s);
            }
        }
        else
            System.out.println("No Command Line arguments");

    }
    static void bufferReader() throws IOException{
        BufferedReader r = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Enter : ");

        int a = Integer.parseInt(r.readLine());
        System.out.println("Value : "+ a);
    }

}
