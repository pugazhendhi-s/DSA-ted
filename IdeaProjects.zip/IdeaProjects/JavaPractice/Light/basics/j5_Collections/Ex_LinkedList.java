package basics.j5_Collections;
//Linked List

import java.util.*;

public class Ex_LinkedList {

    public static void main(String[] args) {
        LinkedList<String> ll = new LinkedList<>();
        String[] a = {"Pugazh", "Legend", "Light Yagami", "Misa"};
        Collections.addAll(ll, a);
        ll.add("Kira");
        ll.add(1, "DeathNote");
        System.out.println(ll);
        ll.remove("Pugazh");
        ll.addFirst("Carpdiem");
        System.out.println(ll);
        System.out.println(ll.contains("Pugazh"));
        ll.pop();
        System.out.println(ll);
    }
}

