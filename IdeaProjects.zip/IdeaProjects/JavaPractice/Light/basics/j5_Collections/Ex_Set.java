package basics.j5_Collections;

import java.util.*;

// Set
public class Ex_Set {
    public static void main(String[] args) {
        //SetEx();
        HashSetEx();
    }
    static void SetEx(){
        Integer[] a = new Integer[] {1,2,3,4,5,6};
        Set<Integer> x = new HashSet<>(Arrays.asList(a));

        Integer[] b = new Integer[]{7,8,9,10,3,4,5};
        Set<Integer> y = new HashSet<>(Arrays.asList(b));

        // Union
        Set<Integer> union = new HashSet<>(x);
        union.addAll(y);
        System.out.println("Union : "+union);

        // Intersection
        Set<Integer> intersection = new HashSet<>(x);
        intersection.retainAll(y);
        System.out.println("Intersection : "+intersection);

        // Difference
        Set<Integer> difference = new HashSet<>(x);
        difference.removeAll(y);
        System.out.println("Difference x-y : "+difference);

        Iterator<Integer> iterator = x.iterator();
        while (iterator.hasNext())
            System.out.print(iterator.next() + " ");
    }
    static void HashSetEx(){

        HashSet<String> a = new HashSet<>();
        String[] x = {"T E D", "Kira", "Misa", "Light"};

        Collections.addAll(a,x); // adding array to hashset
        a.add("Yagami");

        ArrayList<String> z = new ArrayList<>();
        String[] y = {"Goal","Career","Development"};
        Collections.addAll(z,y);

        HashSet<String> b = new HashSet<>(z);

        a.addAll(b);
        System.out.println(a);
        a.remove("Yagami");
        // hashset is not ordered , so remove element using index is not possible
        System.out.println(a);
        System.out.println(a.containsAll(b));
    }
}
