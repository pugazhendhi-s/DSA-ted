package basics.j5_Collections;

import java.util.EnumSet;

// format (conventions capital) and create outside of class
enum Day{
    /**
     * enum is used for creating constant values
     * after compiling enum is defines as a class. below implementation
     * public class Day{
     *     public static final Day SUNDAY = new Day(); // constructor called
     * }
     * ':' not need is only constants in enums means
     * semicolon whenever we finish constants and followed by constructors likewise ';'
     *
     */
    //constant
    SUNDAY, MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY;
    private Day(){  //private always
        System.out.println("Enum constructor called");
        // it is calling as number of constants here 7 its called
    }
}
public class EnumClass {
    public static void main(String[] args) {
        Day d = Day.MONDAY;
        System.out.println(d);  // monday

        switch (d){
            case SUNDAY:
                System.out.println("Hurrah! its a holiday");
                break;
            case MONDAY:
                System.out.println("OOP's Works start day");
                break;
        }
        // to access all constants use enhanced for loop
        System.out.println("\nFor each\n");
        for (Day day : Day.values()){
            System.out.println(day);
        }
        System.out.println("\nRange EnumSet\n");
        for (Day day : EnumSet.range(Day.TUESDAY,Day.FRIDAY)){
            System.out.println(day);
        }
    }
}
