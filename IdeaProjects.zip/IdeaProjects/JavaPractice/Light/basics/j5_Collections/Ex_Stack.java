package basics.j5_Collections;

import com.f9_queueStack.stack.custom.DynamicStack;
import com.f9_queueStack.stack.custom.StackException;

import java.util.HashMap;
import java.util.Scanner;
import java.util.Stack;

/**
 * Store - O(N)
 * Search - O(N)
 * ADD - O(1)
 * Delete - O(1)
 */
public class Ex_Stack {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        Stack<Integer> s = new Stack<>();
    }
    static void validString() {
        System.out.print("Enter testcases = ");
        int tc = Integer.parseInt(sc.nextLine());
        while (tc-- != 0) {
            System.out.print("Enter String length = ");
            int n = Integer.parseInt(sc.nextLine());
            System.out.print("Enter String = ");
            String s = sc.nextLine();
            boolean flag = false;
            Stack<Integer> stack = new Stack<>();
            for (int i=0; i<n; i++){
                if(s.charAt(i) == '0')
                    stack.push(0);
                else if (stack.isEmpty()) {
                    flag = true;
                }
                else
                    stack.pop();
            }
            if(stack.isEmpty() && !flag)
                System.out.println("Yes");
            else
                System.out.println("No");
        }
    }
    static void nextSmaller(){
        int[] a = {2, 3, 20, 2, 13, 46, 8, 40, 20};
        int n = a.length;
        Stack<Integer> stack = new Stack<>();
        HashMap<Integer, Integer> map = new HashMap<>();

        stack.push(a[0]);
        for (int i = 1; i < n; i++) {
            if(stack.empty()) {
                stack.push(a[i]);
                continue;
            }
            while (!stack.empty() && stack.peek() > a[i]) {
                map.put(stack.peek(), i + 1);// store the element and pop
                stack.pop();
            }
            stack.push(a[i]);
        }
        while (!stack.empty())
            map.put(stack.pop(), -1);

        for (int i = 0; i < n; i++) {
            System.out.println(a[i]+" -> "+map.get(a[i]));
        }
    }
    static void reverseString() throws StackException {
        String s = ".tsul si evoL";
        DynamicStack d = new DynamicStack();
        for (int i = 0; i < s.length(); i++) {
            d.push(s.charAt(i));
        }
        String rev="";
        while (!d.empty()){
            rev += (char)d.pop();
        }
        System.out.println(rev);
    }
    static void validString1(){
        /**
         * Input : ((()
         * Output : 2
         * Explanation : ()
         *
         * Input: )()())
         * Output : 4
         * Explanation: ()()
         *
         * Input:  ()(()))))
         * Output: 6
         * Explanation:  ()(())
         */
        String s = sc.nextLine();
        Stack<Integer> stack = new Stack<>();
        stack.push(-1);
        int maxLength = 0;
        for (int i = 0; i < s.length(); i++) {
            if(s.charAt(i) == '(')
                stack.push(i);
            else{
                if(!stack.empty()){
                    stack.pop();
                    if(!stack.empty()){
                        int length = i-stack.peek();
                        maxLength = Math.max(maxLength, length);
                    }
                    else
                        stack.push(i);
                }
            }
        }
        System.out.println(maxLength);
    }


}
