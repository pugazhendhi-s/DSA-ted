package basics.j5_Collections;

import java.util.*;

// ArrayList and vector are same but vector is synchronized
public class Ex_Arraylist {

    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
//        arrayListUsing_ListInterface();
//        arrayListVector();
        multiArrayList();

    }
    static void arrayListUsing_ListInterface(){
        List<String> a = new ArrayList<>();
        a.add("Fck");
        String[] b = {"23134", "243r", "421534", "sffvfsv"};
        Collections.addAll(a, b);

        List<String > c = new ArrayList<>();
        c.add("Abc");
        c.add("Def");

        a.addAll(c);
        a.set(4,"Love");
        a.remove(2);
        for ( String i : a){
            System.out.print(i+" ");
        }
        System.out.println("\n"+a);
        System.out.println(a.hashCode());
    }
    static void arrayListVector(){
       // ArrayList a = new ArrayList();
        ArrayList<Integer> a = new ArrayList<>();
        for (int i = 0; i < 5; i++)
            a.add(i);
        for (Integer integer : a) System.out.println(integer);

        Vector<String> b = new Vector<>();
        b.add("Albert");
        b.add("Baby");
        b.add("CandyQueen");

        Enumeration<String> e = b.elements();
        while (e.hasMoreElements())
            System.out.println(e.nextElement());
    }

    static void multiArrayList(){

        ArrayList<ArrayList<Integer>> list = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            list.add(new ArrayList<>());
        }
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                list.get(i).add(sc.nextInt());
            }
        }
        System.out.println(list);
    }
}
