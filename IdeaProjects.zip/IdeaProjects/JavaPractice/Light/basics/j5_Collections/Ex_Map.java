package basics.j5_Collections;

import java.util.HashMap;
// Load Factor decides "when to increase the number of buckets."

/**
 * The initial capacity of hashmap is=16
 * The default load factor of hashmap=0.75
 * According to the formula as mentioned above: 16*0.75=12,
 * It represents that 12th key-value pair of hashmap will keep its size to 16.
 * As soon as 13th element (key-value pair) will come into the Hashmap.
 * It will increase its size from default 24 = 16 buckets to 25 = 32 buckets.
 * or
 * Size of hashmap (m)/number of buckets (n)  * buckets refers capacity.
 * Now Assume Size = 1, Bucket = 16 =>>> 1/16 = 0.065.. <= 0.75
 * Assume Size = 12, Bucket = 16 =>>> 1/16 = 0.75.. <= 0.75, no need to increase bucket size(capacity)
 * Assume Size = 13, Bucket = 16 =>>> 1/16 = 0.815.. > 0.75, need to increase bucket size(capacity)
 * 2^4 = 16 changed to 2^5 = 32 for 13 Size
 */
public class Ex_Map {
    public static void main(String[] args) {
        HashMap<Integer,String> a = new HashMap<>();
        a.put(1,"TEDDY");
        a.put(2,"Zora");
        a.put(0,"Maxwell");
        System.out.println("Map Size : "+a.size());
        System.out.println("Hashmap Output view : "+a); // {..}
        System.out.println("Hashmap to Set Output view : "+a.entrySet()); // [...]

        HashMap<Integer,String> b = new HashMap<>();
        b.put(5,"Focus");
        b.put(3,"on");
        b.put(9,"Process");

        a.putAll(b);

        for (java.util.Map.Entry<Integer,String> c : a.entrySet()) {
            System.out.println("Keys : "+c.getKey()+", Values : "+c.getValue());
        }


    }
}
