package basics.j7_FileHandling;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Scanner;

public class FileHandling {

    /**
     * Use try catch blocks whenever use of file creating, writing, reading etc
     *
     */
    public static void main(String[] args) {
        readWrite();
    }
    static void checkFile(){
        File file = new File("E:\\Programming\\Zoho\\Zoho.java"); // give one value to constructor
        if (file.exists()){
            System.out.println("File exist");
        }
        else
            System.out.println("File doesn't exit");
        System.out.println(file.getPath());

    }
    static void createFile(){
        try{
            File file = new File("E:\\Programming\\Zoho\\Zoho.txt");

            if (file.createNewFile())
                System.out.println("File created");
            else
                System.out.println("File Already exits");
        }
        catch (Exception e){
            System.out.println("Error occurred while creating a file");
        }
    }
    static void readFile(){
        try{
            File file = new File("E:\\Programming\\Zoho\\Zoho.java");
            Scanner sc = new Scanner(file); // instead of System.in we get input from file

            while (sc.hasNextLine()) {
                System.out.println(sc.nextLine()); // read and print
            }
        }
        catch (Exception e){
            System.out.println("Error occurred while reading a file");
        }
    }
    static void writeFile(){
        try {
            FileWriter fileWriter = new FileWriter("E:\\Programming\\Zoho\\Zoho.txt");
            int i = 10;
            while(i > 0){
                fileWriter.append("Love you All\n"); // 'fileWriter.write' clear all data and write new data into that.
                i--;
            }
            fileWriter.close();

            System.out.println("Successfully written in file..");
        }
        catch (Exception s){
            System.out.println("Error occurred while writing a file");
        }
    }
    static void readWrite(){
        try{
            FileReader fileReader = new FileReader("E:\\Programming\\Java\\File Handling\\input.txt");
            // create a string to store value from read file
            String s = "";
            int i=0;
            while ( (i = fileReader.read()) != -1){
                s += (char)i; // need to convert i because it comes as int.
            }
            System.out.println(s);
            FileWriter fileWriter = new FileWriter("E:\\Programming\\Java\\File Handling\\output.txt");
            fileWriter.write(s);
            fileWriter.write("\nFinished.....");
            fileReader.close();
            fileWriter.close();
            System.out.println("Read and write Successfully..");

        }
        /*try{
            File file = new File("E:\\Programming\\Zoho\\Zoho.java");
            Scanner sc = new Scanner(file); // instead of System.in we get input from file
            FileWriter fw = new FileWriter("E:\\Programming\\Java\\File Handling\\output.txt");
            while (sc.hasNextLine()) {
                 fw.write(sc.nextLine());
            }
            fw.close();
        }*/
        catch (Exception e){
            System.out.println("Error occurred while read and write file");
        }
    }
}
