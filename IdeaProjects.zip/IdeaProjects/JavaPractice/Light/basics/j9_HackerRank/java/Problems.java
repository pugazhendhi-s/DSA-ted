package basics.j9_HackerRank.java;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class Problems {

    public static void main(String[] args) {
        //getSmallestAndLargest();
        //stringCompare();
        //Anagrams();
        //stringSplit();
        //regexPattern();
        //regexTag();
        TimeConversioto24();
    }
    static void TimeConversioto24(){
        Scanner sc = new Scanner(System.in);
        String str = sc.nextLine();
        int hour = Integer.parseInt(str.substring(0,2));
        int min = Integer.parseInt(str.substring(3,5));
        int sec = Integer.parseInt(str.substring(6,8));
        String ampm = str.substring(8);
        System.out.println(ampm+" "+hour+" "+min+" "+sec);
        if(ampm.equals("AM")){
            hour  %= 12;
            System.out.printf("%02d:%02d:%02d",hour,min,sec);
        }
        else if(ampm.equals("PM") && hour < 12){
            hour += 12;
            System.out.printf("%02d:%02d:%02d",hour,min,sec);
        }
    }
    static void regexTag(){
        Scanner scan = new Scanner(System.in);
        System.out.print("Enter testcase : ");
        int testCases = Integer.parseInt(scan.nextLine());

        while (testCases-- > 0) {
            System.out.println("Enter String : ");
            String line = scan.nextLine();

            boolean matchFound = false;
            Pattern r = Pattern.compile("<(.+)>([^<]+)</\\1>");
            Matcher m = r.matcher(line);

            while (m.find()) {
                System.out.println(m.group(1));
                matchFound = true;
            }
            if (!matchFound) {
                System.out.println("None");
            }
        }
    }
    static void regexPattern(){
        String s = "[A-Za-z]"; // check whether it is valid pattern or not
        try {
            Pattern.compile(s);
            System.out.println("Valid");
        }
        catch(Exception e){
            System.out.println("Invalid");
        }

    }
    public static void stringSplit(){
        Scanner scan = new Scanner(System.in);
        scan.useDelimiter("\\Z");
        String s = scan.next().trim();
        if (s.length() > 0) {
            String[] tokens = s.split("[!,?._'@\\s]+");
            System.out.println(tokens.length);
            for(String token : tokens) {
                System.out.println(token);
            }
        } else {
            System.out.println(0);
        }
        scan.close();

    }
    public static void Anagrams(){
        String x = "cukF";
        String y = "fuck";
        String a = x.toLowerCase();
        String b = y.toLowerCase();

        if (a.length() != b.length())
            System.out.println("Not Anagrams");
        int[] count = new int[255];
        for (int i = 0; i < a.length(); i++) {
            char ch = a.charAt(i);
            count[ch]++;
        }
        int[] check = new int[255];
        for (int i = 0; i < b.length(); i++) {
            char ch = b.charAt(i);
            check[ch]++;
        }
        int flag = 0;
        for (int i = 0; i < 255; i++) {
            for (int j = i; j <= i; j++) {
                if(count[i] != check[j]){
                    flag++;
                }
            }
        }
        if(flag == 0)
            System.out.println("Anagrams");
        else
            System.out.println("Not Anagrams");
    }
    public static void getSmallestAndLargest() {
        Scanner scan = new Scanner(System.in);
        String s = scan.next();
        int k = scan.nextInt();
        String smallest = s.substring(0, k);
        String largest = s.substring(0, k);

        for (int i = 0; i < s.length()-(k-1); i++) {
            String temp = s.substring(i, k+i);
            if(temp.compareTo(smallest) < 0){
                smallest = temp;
            }
            if(temp.compareTo(largest) > 0)
                largest = temp;
        }
        System.out.println(smallest + "\n" + largest);
    }
    static void stringCompare(){
        Scanner sc=new Scanner(System.in);
        String A=sc.next();
        String B=sc.next();

        System.out.println(A.length()+B.length());

        /*char[] c = A.toCharArray();
        char[] d = B.toCharArray();

        aa:
        for (int i = 0; i < c.length; i++) {
            bb:
            for (int j = i; j <= i; j++) {
                if(c[i] != d[j]){
                    if((int)c[i] > (int)d[j]){
                        System.out.println("Yes");
                        break aa;
                    }
                    else{
                        System.out.println("No");
                        break aa;
                    }
                }

            }
        }*/
        String result = (A.substring(0,1).toUpperCase().concat(A.substring(1)))+" "+(B.substring(0,1).toUpperCase().concat(B.substring(1)));
        System.out.println(result);
    }
}