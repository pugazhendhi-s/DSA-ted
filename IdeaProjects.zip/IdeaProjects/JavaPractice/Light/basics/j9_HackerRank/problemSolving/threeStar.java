package basics.j9_HackerRank.problemSolving;
import java.util.*;


public class threeStar {

    static class BetweenTwoSets{
        void BetweenTwoSetsEff(){
            int m = 2;
            int n = 3;
            List<Integer> a= new ArrayList<>();
            a.add(2);
            a.add(4);
            List<Integer> b= new ArrayList<>();
            b.add(16);
            b.add(32);
            b.add(96);
            int start = lcm(a);
            int end = gcd(b);
            System.out.println(start+" "+end);
            int count = 0;
            for(int i = start, j =2; i<=end; i=start*j,j++){
                if(end%i==0){ count++;}
            }
            System.out.println(count);
        }
        int lcm(int x, int y){
            // lcm = n1 * n2 / gcd(n1, n2);
            return x * y/(gcd(x,y));
        }
        int lcm(List<Integer> a){
            int res = a.get(0);
            for (int i = 1; i < a.size(); i++) {
                res = lcm(res,a.get(i));
            }
            return res;
        }
        int gcd(int x, int y){
            if(x == 0)
                return y;
            return gcd(y%x, x);
        }
        int gcd(List<Integer> b){
            int res = b.get(0);
            for (int i = 1; i < b.size(); i++) {
                res = gcd(res,b.get(i));
            }
            return res;
        }
        void BetweenTwoSets(){
            int m = 1;
            int n = 3;
            int a[] = {2};
            int b[] = {10,20,12};
            int start = a[m-1]; int end = b[0];
            int count = 0;
            while (start <= end){
                int i=0; int j=0; int flag=0;
                while(i<m || j<n){
                    System.out.println(a[i]+" "+b[j]+" "+start);
                    if(start % a[i] != 0 || b[j] % start != 0) {
                        flag = 1;break;
                    }
                    System.out.println("i : "+i+" j : "+j);
                    i++; j++;
                }
                if(flag == 0) {
                    count++;
                    System.out.println(start+" add");
                }
                start++;
            }
            System.out.println(count);
        }
    }
    public static void main(String[] args){
        electronicShop();
    }
    static void minMax(){
        Scanner sc =  new Scanner(System.in);
        int n = sc.nextInt();
        int[] a = new int[n];
        int[] b = new int[n];
        for (int i = 0; i < a.length; i++) {
            a[i] = sc.nextInt();
        }
        for (int i = 0; i < a.length; i++) {
            if(a[i] < 38)
                b[i] = a[i];
            else if(a[i] % 5 == 0)
                b[i] = a[i];
            else if((a[i])%5 > 3){
                b[i] = a[i] + (5-(a[i]%5));
            }
            else{
                b[i] = a[i];
            }
        }
        for (int i:b) {
            System.out.print(i+" ");
        }
    }
    static void appleOrange(){
        Scanner sc = new Scanner(System.in);
        int s = sc.nextInt();
        int t = sc.nextInt();
        int a = sc.nextInt();
        int b = sc.nextInt();
        int m = sc.nextInt();
        int n = sc.nextInt();
        int []apples = new int[m];
        int []orange = new int[n];
        for (int i = 0; i < m; i++) {
            apples[i] = sc.nextInt();
        }
        for (int i = 0; i < n; i++) {
            orange[i] = sc.nextInt();
        }
        int countApple = 0; int countOrange = 0;
        for(int i=0; i<m; i++){
            int sum = apples[i]+a;
            if(sum >= s && sum <= t)
                countApple++;
        }
        for(int i=0; i<n; i++){
            int sum = orange[i]+b;
            if(sum >= s && sum <= t)
                countOrange++;
        }
        System.err.println(countApple+"\n"+countOrange);
    }
    static void migratingBirds(){ // character with max frequency with min value
        List<Integer> li = new ArrayList<>(Arrays.asList(1,2,3,4,4,5,4,1,5,5));

        Map<Integer,Integer> hs = new HashMap<>();
        for (int i = 0; i < li.size(); i++) {
            int a = li.get(i);
            if(hs.containsKey(a))
                hs.put(a, hs.getOrDefault(a,0)+1);
            else
                hs.put(a,1);
        }
        int key = Collections.max(hs.entrySet(), Map.Entry.comparingByValue()).getKey();
        System.out.println(key);
    }
    static void birthdayBar() {
        List<Integer> s = new ArrayList<>(Arrays.asList(1,2,1,3,2));
        int d = 3;
        int m = 2;
        int n = s.size();
        int sum = 0; int count = 0;
        for (int i=0; i<m; i++)
            sum += s.get(i);
        System.out.println(sum);
        for (int i = 0; i < n-m+1; i++) {
            if(sum == d)
                count++;
            if(i+m < n)
                sum = sum - s.get(i) + s.get(i+m);
            System.out.println(sum);
        }
        System.out.print(count);
    }
    static void drawingBook(){
        int n = 6; //noOfPages
        int p = 5;  // pageToOpen
        int front = p;
        int back = n-p;
        if(front > back){
            if(n%2 == 0 && back == 1) {
                System.out.println(1);
            }
            else
                System.out.println(back / 2);
        }
        else
            System.out.println(front/2);
    }
    static void countingValleys(){
        String path = "DDUUDDUDUUUD";
        int steps = 0;
        int u = 0, d = 0;
        for (int i=0; i<path.length(); i++){
            char ch = path.charAt(i);
            if(ch == 'U'){
                u++; d--;
            }
            else if(ch == 'D' && u == 0){
                u--;
                steps++;
            }
            else if(ch == 'D')
                u--;
        }
        System.out.println(steps);
    }
    static void electronicShop(){
        // k+d which is less{(k+d-b) is less} than equal to b.
        int[] k = {2,7,9,1};
        int[] d = {8,2};
        int b = 16;
        int max = -1;
        for (int i:k){
            for(int j:d){
                if(i+j <= b && i+j > max){
                    max = i+j;
                }
            }
        }
        System.out.println(max);
    }


}
