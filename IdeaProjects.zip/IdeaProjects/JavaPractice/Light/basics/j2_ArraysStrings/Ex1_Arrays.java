package basics.j2_ArraysStrings;

import java.util.Scanner;

/**
 * Simple Array
 * int[] a; int []b; int c[]; // Declaration
 * int[] d = new int[5]; Declaration and Instantiation
 * int[] e = {1,2,3,4,5}; Declaration, Instantiation // Arrays literal
 * new int[]{1,2,3,4,5}; Anonymous Array *Passed in method or return array
 *
 * Multidimensional Array
 * int[][] a; int [][]b; int []c[]; int d[][]; // Declaration
 * int[][] d = new int[2][5]; Declaration and Instantiation
 * int[][] e = {{1,2,3,4,5},{6,7,8,9,0}}; Declaration, Instantiation // Array literal
 */

public class Ex1_Arrays {
    public static void main(String[] args) {
        // array();
        // multiDimensional();
        jaggedArray();
    }
    static void array() {
        int[] d = new int[5]; // Declaration and Instantiation
        for (int i = 0; i < d.length; i++) {
            d[i] = i+10;
        }
        for (int i = 0; i < d.length; i++) {
            System.out.println(d[i]);
        }
        System.out.print("For-Each : ");
        for (int i: d){
            System.out.print(i+" ");
        }
    }
    static void multiDimensional(){
        int[][] e = {{1,2,3,4,5},{6,7,8,9,0}};
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 5; j++) {
                System.out.print(e[i][j]+" ");
            }
            System.out.println();
        }
    }
    static void jaggedArray(){
        Scanner sc = new Scanner(System.in);
        /*int a[][] = new int[][]{
                {1,2,3,4},
                {5,6},
                {7,8,9}
        };
              or
        int b[][] = {
                {1,2,3,4},
                {5,6},
                {7,8,9}
        };
              or
        int[][] c = new int[][]{
                new int[]{1,2,3,4},
                new int[]{5,6},
                new int[]{7,8,9}
        };*/
        int a[][] = new int[3][];
        a[0] = new int[4];
        a[1] = new int[2];
        a[2] = new int[3];
        int val = 0;
        System.out.println("Enter values : ");
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                a[i][j] = sc.nextInt();
            }
            System.out.println();
        }
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                System.out.print(a[i][j]+" ");
            }
            System.out.println();
        }

    }
}
