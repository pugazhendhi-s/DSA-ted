package basics.j2_ArraysStrings;

// String Buffer
public class Ex3_StringBuilderBuffer {

    public static void main(String[] args) {
          Ex3_StringBuilderBuffer obj = new Ex3_StringBuilderBuffer();
          obj.stringBuffer();
          stringBuilder();
    }

    void stringBuffer() {
        StringBuffer a = new StringBuffer("Somethings have to be end for better things to begin...!");
        StringBuffer b = new StringBuffer("Misa Amane");
        System.out.println("Length of a : "+a.length()+", Capacity of a : "+a.capacity());
        System.out.println("Length of b :"+b.length()+", Capacity of b : "+b.capacity());
        System.out.println(a.append(b));
        System.out.println(a.append(999));
        System.out.println(a.insert(0,"There is a Saying that, "));
        System.out.println(a.insert(22,'!'));
        System.out.println("String reverse : "+ a.reverse()+"\nString Normal : "+a.reverse());
        System.out.println(a.deleteCharAt(22));
        System.out.println(a.delete(0,24));
        System.out.println(a.delete(60,69));
        System.out.println(a.replace(56, 60, ""));


    }

    static void stringBuilder(){
        StringBuilder a = new StringBuilder();
        System.out.println("Length : "+a.length()+", Capacity : "+a.capacity());
        a.append("Light Yagami..........................");
        System.out.println("Length : "+a.length()+", Capacity : "+a.capacity());
        System.out.println(a.append(" Kira")+" "+a.capacity()+" "+a.length());
    }
}
