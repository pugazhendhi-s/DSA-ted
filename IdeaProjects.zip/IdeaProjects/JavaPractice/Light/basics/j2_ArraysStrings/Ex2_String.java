package basics.j2_ArraysStrings;


public class Ex2_String {

    public static void main(String[] args) {
        Ex2_String obj = new Ex2_String();
        obj.stringMethods();
        basic();
    }
    static void basic(){
        String a = "T E D";
        String b = new String("Light");

        byte[] c = {65,90,97,122};
        String d = new String(c);
        System.out.println(d);

        char[] e = {'T', 'E', 'D'};
        String f = new String(e);
        System.out.println(f);
    }
    void stringMethods(){

        String str = "Everything happens for a reason";
        System.out.println(str.length());
        System.out.println(str.charAt(17));
        System.out.println(str.substring(17));
        System.out.println(str.substring(2, 18)); // beginning inclusive end exclusive

        String ak = new String(", So accept ...");
        String big = str.concat(ak); // str+ak;
        System.out.println(big);
        System.out.println(big.indexOf("er"));
        System.out.println(big.lastIndexOf("er"));
        System.out.println(big.indexOf('e',777));
        System.out.println("Intern : "+ big.intern());
        System.out.println(big.equalsIgnoreCase(ak));
        System.out.println(str.equalsIgnoreCase(big));
        System.out.println(big.toUpperCase());
        System.out.println(big.toLowerCase());
        System.out.println(str.compareTo(big));
        System.out.println(str.compareTo(ak));
        System.out.println("abaa".compareTo("abad"));
        System.out.println(big.compareToIgnoreCase(str));
        System.out.println(str.compareToIgnoreCase(big));

        String a = "     Love is   Sacrifice   ";
        System.out.println(a.trim());
        System.out.println(a.replace(' ','_'));
        System.out.println(big.contains("accept"));

    }
}
