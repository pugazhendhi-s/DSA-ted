package sdesheet.backtracking;
import java.util.*;

public class Permutations {

    public static void main(String[] args) {

        int[] nums = {1, 2, 3};
        List<List<Integer>> list = permute(nums);
        System.out.println(list);
    }

    public static List<List<Integer>> permute(int[] nums) {

        List<List<Integer>> list = new ArrayList<>();
        return func(nums, new ArrayList<>(), list, new HashSet<>());
    }

    public static List<List<Integer>> func(int[] nums, List<Integer> li,
                                    List<List<Integer>> list, HashSet<Integer> set) {

        if (set.size() == nums.length) {
            list.add(new ArrayList<>(li));
            return list;
        }

        for (int i = 0; i < nums.length; i++) {
            if (set.add(i)) {
                li.add(nums[i]);
                func(nums, li, list, set);
                set.remove(i);
                li.remove(li.size()-1);
            }
        }
        return list;
    }
    // by swapping values
    private void recurPermute(int index, int[] nums, List < List < Integer >> ans) {
        if (index == nums.length) {
            // copy the ds to ans
            List < Integer > ds = new ArrayList < > ();
            for (int num : nums) {
                ds.add(num);
            }
            ans.add(new ArrayList < > (ds));
            return;
        }
        for (int i = index; i < nums.length; i++) {
            swap(i, index, nums);
            recurPermute(index + 1, nums, ans);
            swap(i, index, nums);
        }
    }
    private void swap(int i, int j, int[] nums) {
        int t = nums[i];
        nums[i] = nums[j];
        nums[j] = t;
    }
}
