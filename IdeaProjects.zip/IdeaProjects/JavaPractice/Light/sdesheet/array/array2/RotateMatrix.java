package sdesheet.array.array2;

import java.util.Arrays;

public class RotateMatrix {

    public static void main(String[] args) {

        int[][] mat = {
                {1,2,3},
                {4,5,6},
                {7,8,9}
        };

        rotate(mat);

        for (int[] ints : mat) {
            System.out.println(Arrays.toString(ints));
        }
    }

    public static void rotate(int[][] mat) {

        int n = mat.length;

        // transpose
        for (int i = 0; i < n; i++) {
            for (int j = i; j < n; j++) {
                int temp = mat[i][j];
                mat[i][j] = mat[j][i];
                mat[j][i] = temp;
            }
        }

        // flip

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n/2; j++) {
                int temp = mat[i][j];
                mat[i][j] = mat[i][n - 1 - j];
                mat[i][n - 1 - j] = temp;
            }
        }
    }
}
