package sdesheet.array.array2;

public class DuplicateNumber {

    public static void main(String[] args) {

        int[] nums = {1,3,4,2,2};
        int val = findDuplicate(nums);
    }

    // visited index
    public static int findDuplicate(int[] nums) {

        int len = nums.length;
        for (int num : nums) {
            int idx = Math.abs(num);
            if (nums[idx] < 0) {
                return idx;
            }
            nums[idx] = -nums[idx];
        }
        return len;
    }

    public static int indexSort(int[] nums) {

        int i = 0;
        while (i < nums.length) {
            int n = nums[i];
            if (n == i+1) {
                i++;
            }
            else if (n == nums[n-1]) {
                return n;
            }
            else {
                nums[i] = nums[n-1];
                nums[n-1] = n;
            }
        }
        return nums.length;
    }

    public static int binarySearch(int[] nums) {

        int lo = 0;
        int hi = nums.length-1;
        while (lo < hi) {
            int count = 0;
            int mid = (lo + hi)/2;
            for (int i = 0; i <= nums.length; i++) {
                if (nums[i] <= mid) {
                    count++;
                }
            }
            if (count <= mid) {
                lo = mid -1;
            }
            else hi = mid;
        }
        return lo;
    }
}
