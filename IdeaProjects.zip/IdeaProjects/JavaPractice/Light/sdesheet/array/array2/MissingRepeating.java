package sdesheet.array.array2;

public class MissingRepeating {

    public static void main(String[] args) {

    }

    public static int[] countSort(int[] arr, int n) {

        int missing = 0;
        int repeated = 0;
        int[] nums = new int[arr.length + 1];

        for (int val : arr) {
            if (nums[val] < 0) {
                repeated = val;
            }
            nums[val] = -1;
        }
        for (int i = 0;  i < nums.length; i++) {
            if (nums[i] != -1) {
                missing = i;
            }
        }

        return new int[] {missing, repeated};
    }

    public static int[] missingAndRepeating(int[] nums, int n) {

        long sumN = (long) n * (n+1)/2;
        long sqSumN = n * (n + 1) * (2L * n + 1) / 6;

        for (int num : nums) {
            sumN -= num;
            sqSumN -= ((long) num * num);
        }

        int missing = (int)(sumN + (sqSumN/ sumN)) / 2;
        int duplicate = missing - (int)sumN;

        return new int[] {missing, duplicate};
    }

}
