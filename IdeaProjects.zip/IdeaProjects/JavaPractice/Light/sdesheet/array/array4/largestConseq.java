package sdesheet.array.array4;

import java.util.*;

public class largestConseq {

    public static void main(String[] args) {

        int[] nums = {100,4,200,1,3,2};
        int maxConseq = longestConsecutive(nums);
        System.out.println(maxConseq);
    }

    public static int longestConsecutive(int[] nums) {

        Set<Integer> set = new HashSet<>();
        for (int num: nums) {
            set.add(num);
        }
        int maxConseq = 1;
        for (int num : nums) {
            int conseq = 1;
            while (set.contains(num-1)) {
                conseq++;
                num = num-1;
            }
            maxConseq = Math.max(conseq, maxConseq);
            if (maxConseq == set.size()) return maxConseq;
        }
        return maxConseq;
    }
}
