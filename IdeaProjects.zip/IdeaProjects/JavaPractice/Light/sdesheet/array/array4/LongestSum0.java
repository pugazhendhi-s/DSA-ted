package sdesheet.array.array4;

import java.util.ArrayList;
import java.util.HashMap;

public class LongestSum0 {

    public static void main(String[] args) {

        int[] nums = {15,-2,2,-8,1,7,10,23};
        int n = 8;
        int maxLen = longestSubArrSum0(nums, n);
        System.out.println(maxLen);
    }

    public static int longestSubArrSum0(int[] nums, int n)
    {
        // Your code here

        HashMap<Integer, Integer> map = new HashMap<>();
        map.put(0,-1);
        int sum = 0;
        int maxLen = 0;

        for (int i = 0; i < n; i++) {
            sum += nums[i];

            if (map.containsKey(sum)) {
                maxLen = Math.max(maxLen, i - map.get(sum));
            }
            else map.put(sum, i);
        }
        return maxLen;
    }

    public static int subarraysXor(ArrayList<Integer> nums, int target) {
        
        HashMap<Integer, Integer> map = new HashMap<>();
        int cpx = 0; // prefix xor
        int count = 0;
        for (int num : nums) {
            cpx ^= num;
            int xor = cpx ^ target; // like sum, here xor
            if (map.get(xor) != null) {
                count += map.get(xor);
            }
            if (cpx == target) count++;
            if (map.get(cpx) != null) {
                map.put(cpx, map.get(cpx)+1);
            }
            else map.put(cpx, 1);
        }
        return count;
    }
}
