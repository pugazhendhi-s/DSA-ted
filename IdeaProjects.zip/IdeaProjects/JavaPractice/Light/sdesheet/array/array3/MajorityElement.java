package sdesheet.array.array3;


import java.util.ArrayList;
import java.util.List;

public class MajorityElement {

    public static void main(String[] args) {

        int[] nums = {2,2,1,2,2};
        int element = majorityElement(nums);
        System.out.println(element);
    }

    // Boyer - Moore's voting method
    public static int majorityElement(int[] nums) {

        int n = nums.length;
        int major = nums[0];
        int count = 1;
        for(int i=1; i<n; i++){
            if (count == 0) {
                count++;
                major = nums[i];
            }
            else if(major == nums[i]) {
                count++;
            }
            else count--;
        }
        return major;

        //        if(a.length == 1)
//            return a[0];
//        Arrays.sort(a);
//        return a[a.length/2];
    }

    public static List<Integer> majorityElementII(int[] nums) {

        int n = nums.length;
        int c1 = 0, c2 = 0;
        int n1 = -1, n2 = -1;

        for (int num : nums) {
            if (n1 == num) {
                c1++;
            }
            else if (n2 == num) {
                c2++;
            }
            else if (c1 == 0) {
                n1 = num;
                c1 = 1;
            }
            else if (c2 == 0) {
                n2 = num;
                c2 = 1;
            }
            else {
                c1--; c2--;
            }
        }
        c1 = 0;
        c2 = 0;
        for (int num : nums) {
            if (n1 == num){
                c1++;
            }
            else if(n2 == num) {
                c2++;
            }
        }
        List<Integer> list = new ArrayList<>();

        if (c1 > n/3) list.add(n1);
        if(c2 > n/3) list.add(n2);

        return list;
    }
}
