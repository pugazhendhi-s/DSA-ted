package sdesheet.array.array3;

public class Power {

    public static void main(String[] args) {

        int x = 2;
        int n = 7;
        double power = myPow(x, n);
        System.out.println(power);
    }

    public static double myPow(double x, int n) {
        double res = 1.0;
        for (int i = Math.abs(n); i != 0; i/=2) {
            if (i % 2 != 0) {
                res *= x;
            }
            x *= x;
        }
        return n > 0 ? res : 1 / res;
    }
}
