package sdesheet.array.array3;

public class ReversePairs {

    public static void main(String[] args) {

    }

    private int[] helper;
    public int reversePairs(int[] nums) {
        helper = new int[nums.length];
        return split(0, nums.length-1, nums);
    }

    private void merge(int lo, int mid, int hi, int[] nums) {

        if (hi + 1 - lo >= 0)
            System.arraycopy(nums, lo, helper, lo, hi + 1 - lo);
        int i=lo, j=mid+1;
        int k = lo;

        while (i <= mid || j <= hi) {
            if (i > mid ||(j <= hi && helper[i] >= helper[j])) {
                nums[k++] = helper[j++];
            }
            else nums[k++] = helper[i++];
        }
    }

    private int split(int lo, int hi, int[] nums) {
        if (lo >= hi) return 0;

        int mid = lo + (hi - lo)/2;
        int count = split(lo, mid, nums) + split(mid+1, hi, nums);

        for (int i=lo, j = mid+1; i <= mid; i++) {
            while (j <= hi && nums[i]/2.0 > nums[j]) j++;
            count += j-(mid+1);
        }
        merge(lo, mid, hi, nums);
        return count;
    }
}
