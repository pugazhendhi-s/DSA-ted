package sdesheet.array.array1;

public class KadaneAlgorithm {   // MaxSubArraySum

    public static void main(String[] args) {

        int[] nums = {-2,1,-3,4,-1,2,1,-5,4};
    }

    public static int maxSubArray(int[] nums) {

        int maxSum = nums[0];
        int sum = 0;

        for (int num : nums) {
            sum += num;
            if (sum <= num) {
                sum = num;
            }
            maxSum = Math.max(maxSum, sum);
        }
        return maxSum;
    }
}
