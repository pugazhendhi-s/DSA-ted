package sdesheet.array.array1;
import java.util.*;

public class PascalsTriangle {

    public static void main(String[] args) {

        pascalTriangle();
    }

    public List<List<Integer>> generate(int numRows) {

        List<List<Integer>> res = new ArrayList<>();
        List<Integer> row, pre = null;

        for (int i = 0; i < numRows; ++i) {
            row = new ArrayList<>();

            for (int j = 0; j <= i; ++j)
                if (j == 0 || j == i)
                    row.add(1);
                else
                    row.add(pre.get(j - 1) + pre.get(j));
            pre = row;
            res.add(row);
        }
        return res;
    }

    public static void pascalTriangle(){
        // formula = n!/(n-r)!r!
        int n = 4;
        for (int row = 0; row <= n; row++) {
            int totCols = row;
            int totSpace = n-totCols;
            for (int space = 0; space <= totSpace; space++) {
                System.out.print(" ");
            }

            for (int col = 0; col <= totCols; col++) {

                int fact = factorial(row) / (factorial(row - col) * factorial(col));
                System.out.print(fact+" ");
            }
            System.out.println();
        }
    }

    public static int factorial(int n){
        int prev = 1;
        for (int curr = 2; curr <= n; curr++) {
            prev = curr * prev;
        }
        return prev;
    }
}
