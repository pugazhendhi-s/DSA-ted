package contest.leetcode;

public class LongestCycle {

    public static void main(String[] args) {

        int[] edges = {1,2,0,4,5,6,3,8,9,7};
        LongestCycle l = new LongestCycle();
        int longest = l.longestCycle(edges);
        System.out.println(longest);
    }
    int len = 1;
    int max = -1;
    public int longestCycle(int[] edges) {
        int n = edges.length;
        int[] vis = new int[n];
        for (int i=0; i<n; i++) {
            if (vis[i] == 0) {
                len = 1;
                vis[i] = len;
                func(i, vis, edges);
            }
        }
        return max;
    }

    public void func(int node, int[] vis, int[] edges) {
        len++;
        int curr = edges[node];
        if (curr == -1) return;
        if (vis[curr] != 0) {
            max = Math.max(max, len - vis[curr]);
            return;
        }
        vis[curr] = len;
        func(curr, vis, edges);
    }
}
