package contest.geeksforgeeks;

public class D02_Sticks {

    public static void main(String[] args) {
        int n = 4;
        int[] a = {3, 4, 6, 5};
        int[] b = {2, 3, 1, 6};
        long maxi = maxPossibleValue(n, a, b);
        System.out.println(maxi);
    }

    private static long maxPossibleValue(int N, int[] a ,int[] b) {

        long sum = 0;
        long prev = 0;
        long min = Integer.MAX_VALUE;

        for (int i=0; i<N; i++) {
            long side = a[i];
            long freq = b[i]/4;

            sum += (4 * side * freq);
            if (b[i] != 1) min = Math.min(side, min);
            if (b[i] % 4 > 1) {
                if (prev == 0) {
                    prev = side;
                }
                else {
                    sum += (prev*2 + side*2);
                    prev = 0;
                }
            }
        }
        if (prev != 0) {
            sum = Math.max(sum, sum- 2*min + 2*prev);
        }
        return sum;
    }
}
