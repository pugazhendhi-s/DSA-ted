package contest.contest18;

public class Main {

    public static void main(String[] args) {



        int x = 10;
        int y = 5;
        try {
            System.out.println(10/0);
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
        }
        finally {
            System.out.println("foin");
        }
        System.out.println("emd");
    }
}
