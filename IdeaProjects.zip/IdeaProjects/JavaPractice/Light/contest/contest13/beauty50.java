package contest.contest13;
import java.util.*;
public class beauty50 {
    public static void main(String[] args) {
        int[] a = {2,5,6,2,6,9,9,9,9};
        sortByValue(a);
        System.out.println(Arrays.toString(a));
    }
    public static long calcBeauty(int[] a, int n){
        Map<Integer, List<Integer>> map = new HashMap<>();
        for(int i=0; i<a.length; i++){
            if(!map.containsKey(a[i])) {
                map.put(a[i], new ArrayList<>());
                map.get(a[i]).add(-1);
            }
            map.get(a[i]).add(i);
        }
        for (int val: a) {
            if(!map.get(val).contains(n))
                map.get(val).add(n);
        }
        long beauty = 0;
        for (Map.Entry<Integer, List<Integer>> x : map.entrySet()) {
            List<Integer> list = x.getValue();
            for (int i = 1; i < list.size()-1; i++) {
                int left = list.get(i) - list.get(i-1);
                int right = list.get(i+1)-list.get(i);
                beauty +=((long) left * right);
            }
        }
        return beauty;
    }
    public static void sortByValue(int[] a){
        Map<Integer, Integer> map = new HashMap<>();
        for (int x : a) {
            map.put(x, map.getOrDefault(x, 0)+1);
        }
        List<Map.Entry<Integer, Integer>> entryList = new LinkedList<>(map.entrySet());
        entryList.sort(Map.Entry.comparingByValue(Comparator.reverseOrder()));
        int index = 0;
        for (Map.Entry<Integer,Integer> entry : entryList) {
            int freq = entry.getValue();
            for (int i = 0; i < freq; i++) {
                a[index++] = entry.getKey();
            }
        }
    }
}
