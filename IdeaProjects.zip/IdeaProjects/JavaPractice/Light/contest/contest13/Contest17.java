package contest.contest13;
import java.util.*;
public class Contest17 {

    public static void main(String[] args) {
        String[] s = {"zkfcowyvgneobcyay", "rekorku", "sbokgmealjqqhcwebs", "yshkw"};

    }

    public int[] findBots(String names[], int n){

        int[] ans = new int[n];
        int k=0;
        for (String s : names){
            HashSet<Character> set = new HashSet<>();
            for (int i=0; i<s.length();i+=2) {
                set.add(s.charAt(i));
            }
            ans[k++] = isPrime(set.size()) ? 1 : 0;
        }
        return ans;
    }

    public boolean isPrime(int n) {
        for (int i=2; i*i<= n; i++) {
            if (n % 2 == 0) return false;
        }
        return n != 0 && n != 1;
    }
}
