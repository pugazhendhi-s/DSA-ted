package contest.contest13;

import java.util.*;

public class FrequencySort {
    public static void main(String[] args) {
        String res = frequencySort("tree");
        System.out.println(res);
    }
    public static String frequencySort(String s) {
        char []ch= s.toCharArray();
        int n = ch.length;
        int[][] freq = new int[n][2];
        Arrays.sort(ch);
        int idx = 0;
        freq[idx][0] = ch[0];
        for (int i=1; i<n; i++) {
            if (ch[i] == ch[i-1]) freq[idx][1] += 1;
            else freq[++idx][0] = ch[i];
        }

        Arrays.sort(freq, (a, b)->b[1]-a[1]);
        StringBuilder sb = new StringBuilder();
        for (int i=0; i<=idx; i++) {
            char temp = (char)(freq[idx][0]);
            for (int j=0; j<=freq[idx][1]; j++) {
                sb.append(temp);
            }
        }
        return sb.toString();
    }
    public static String bucketSort(String s) {
        Map<Character, Integer> map = new HashMap<>();
        for (char c : s.toCharArray())
            map.put(c, map.getOrDefault(c, 0) + 1);

        List<Character>[] bucket = new List[s.length() + 1];
        for (char key : map.keySet()) {
            int frequency = map.get(key);
            if (bucket[frequency] == null) bucket[frequency] = new ArrayList<>();
            bucket[frequency].add(key);
        }

        StringBuilder sb = new StringBuilder();
        for (int pos = bucket.length - 1; pos >= 0; pos--)
            if (bucket[pos] != null)
                for (char c : bucket[pos])
                    for (int i = 0; i < pos; i++)
                        sb.append(c);

        return sb.toString();
    }
    public String frequencyPqEntry(String s) {

        Map<Character, Integer> map = new HashMap<>();
        for (char ch : s.toCharArray()) {
            map.put(ch, map.getOrDefault(ch, 0)+1);
        }
        PriorityQueue<Map.Entry<Character, Integer>> maxHeap =
                new PriorityQueue<>((a, b) -> b.getValue() - a.getValue());
        maxHeap.addAll(map.entrySet());
        StringBuilder sb = new StringBuilder();

        while ( !maxHeap.isEmpty()) {
            Map.Entry<Character, Integer> e = maxHeap.poll();
            for (int i=0; i<e.getValue(); i++) {
                sb.append(e.getKey());
            }
        }
        return sb.toString();
    }

    public static String frequencyPqSB(String s) {
        Map<Character, StringBuilder> map = new HashMap<>();
        for (char ch : s.toCharArray()) {
            map.put(ch, map.getOrDefault(ch, new StringBuilder()).append(ch));
        }
        PriorityQueue<StringBuilder> maxHeap =
                new PriorityQueue<>((a, b) -> b.length() - a.length());
        maxHeap.addAll(map.values());
        StringBuilder sb = new StringBuilder();
        while ( !maxHeap.isEmpty()) {
            sb.append(maxHeap.poll());
        }
        return sb.toString();
    }
}
