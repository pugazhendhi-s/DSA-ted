package contest.contest13;


public class Contest {

    public static void main(String[] args) {

    }

    public boolean isCircularSentence(String s) {

        int n = s.length();
        if (s.charAt(0) != s.charAt(n-1)) return false;

        for (int i = 1; i < n; i++) {
            if (s.charAt(i-1) == ' ') {
                if(s.charAt(i) != s.charAt(i-2)) return false;
            }
        }
        return true;
    }
}
