package contest.hackerrank;

import java.math.BigInteger;

public class D01_BigInteger {

    public static void main(String[] args) {

        extraLongFactorials(30);
    }

    public static void extraLongFactorials(int n) {

        BigInteger fact = BigInteger.ONE;

        while (n > 0) {
            fact = fact.multiply(BigInteger.valueOf(n));
            n--;
        }

        System.out.println(fact);

    }

}
