package contest.hackerrank;
import java.util.*;

public class LeaderBoard {

    public static void main(String[] args) {
        List<Integer> ranked = new ArrayList<>(Arrays.asList(100, 90, 90, 80));
        List<Integer> player = new ArrayList<>(Arrays.asList(70, 80, 105));
        List<Integer> list = climbingLeaderboard(ranked, player);
        System.out.println(list);

    }
    public static List<Integer> climbingLeaderboard(List<Integer> ranked, List<Integer> player) {
        Map<Integer, Integer> map = new HashMap<>();
        ArrayList<Integer> list = new ArrayList<>();
        int rank = 1;
        for (int x : ranked) {
            if (!map.containsKey(x)) {
                map.put(x, rank++);
            }
        }
        int initial = ranked.size()-1;
        for (int play : player) {
            for (int i = initial; i >= 0; i--) {
                if (play >= ranked.get(i)) {
                    rank = map.get(ranked.get(i));
                    initial = i-1;
                }
                else break;
            }
            list.add(rank);
        }
        return list;
    }

}
