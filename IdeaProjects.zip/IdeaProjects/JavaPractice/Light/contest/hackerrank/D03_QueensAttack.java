package contest.hackerrank;
import java.util.*;

public class D03_QueensAttack {

    public static void main(String[] args) {

        int n = 5;
        int k = 3;
        int rq = 4;
        int cq = 3;

        List<List<Integer>> obs = new ArrayList<>();
        obs.add(new ArrayList<>(Arrays.asList(5,5)));
        obs.add(new ArrayList<>(Arrays.asList(4,2)));
        obs.add(new ArrayList<>(Arrays.asList(2,3)));
        int attack = queensAttackEff(n, k, rq, cq, obs);
        System.out.println(attack);

    }

    // efficient
    public static int queensAttackEff(int n, int k, int rq, int cq, List<List<Integer>> obstacles) {

        int left = 0, right = 0,top = 0, down = 0,
                topLeft = 0, topRight = 0, downLeft = 0, downRight = 0;

        int attacks = 2 * (n-1) + Math.min(n-rq, cq-1) + Math.min(n-rq, n-cq) +
                                        Math.min(rq-1, cq-1) + Math.min(rq-1, n-cq);

        for (List<Integer> obs : obstacles) {
            int x = obs.get(0); int y = obs.get(1);
            if (x == rq) {
                if (y > cq) right = Math.max(right, n-y+1);
                else left = Math.max(left, y);
            }
            else if (y == cq) {
                if (x > rq) top = Math.max(top, n-x+1);
                else down = Math.max(down, x);
            }
            else if (Math.abs(rq - x) == Math.abs(cq - y)) {
                // top
                if (x > rq && y < cq) {
                    topLeft = Math.max(topLeft, Math.min(n-x, y-1) + 1);
                }
                else if (x > rq) {
                    topRight = Math.max(topRight, Math.min(n-x, n-y) + 1);
                }
                // down
                else if (y < cq) {
                    downLeft = Math.max(downLeft, Math.min(x-1, y-1) + 1);
                }
                else {
                    downRight = Math.max(downRight, Math.min(x-1, n-y) + 1);
                }
            }
        }
        attacks -= (left + right + top + down + topLeft + topRight + downLeft + downRight);
        return attacks;
    }

    public static int queensAttack(int n, int k, int rq, int cq, List<List<Integer>> obstacles) {

        int[][] dir= {{-1,-1}, {0,-1}, {1,-1}, {1, 0}, {1, 1}, {0, 1}, {-1,1}, {-1,0}};

        int attack = 0;

        for (int[] d : dir) {
            int row = rq + d[0];
            int col = cq + d[1];
            while (row > 0 && row<= n && col > 0 && col <= n) {
                if (isAttack(row, col, obstacles)) {
                    attack++;
                    row += d[0];
                    col += d[1];
                }
                else break;
            }
        }
        return attack;
    }
    public static boolean isAttack(int r, int c, List<List<Integer>> obstacles) {
        for (List<Integer> obs : obstacles) {
            if (obs.get(0) == r && obs.get(1) == c) {
                return false;
            }
        }
        return true;
    }

}
