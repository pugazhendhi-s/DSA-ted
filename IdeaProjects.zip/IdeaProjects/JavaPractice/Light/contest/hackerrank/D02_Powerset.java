package contest.hackerrank;
import java.util.*;

public class D02_Powerset {

    public static void main(String[] args) {

        List<Integer> nums = new ArrayList<>(Arrays.asList(1,2,3));
        List<List<Integer>> list = powerset(nums);
        System.out.println(list);
    }

    public static int nonDivisibleSubset(int k, List<Integer> s) {

        if (k < 2) return 1;
        int[] fq = new int[k];

        for (int num : s) {
            fq[num % k]++;
        }
        int cnt = 0;
        for (int i=1; i<k/2; i++) {
            cnt += Math.max(fq[i], fq[k-i]);
        }
        if (fq[0] > 1) cnt++;
        if (k % 2 == 0 && fq[k/2] > 0) cnt++;
        if (k % 2 != 0)  {
            cnt += Math.max(fq[k/2], fq[k-k/2]);
        }
        return cnt;
    }

    public static int nonDivisibleSubsetBF(int d, List<Integer> s) {

        List<List<Integer>> list = powerset(s);
        int max = 0;

        for (List<Integer> li : list) {
            boolean flag = true;
            int n = li.size();

            outer:
            for (int j = 0; j < n - 1; j++) {
                for (int k = j + 1; k < n; k++) {
                    int sum = li.get(j) + li.get(k);
                    if (sum % d == 0) {
                        flag = false;
                        break outer;
                    }
                }
            }
            if (flag) {
                max = Math.max(max, n);
            }
        }
        return max;
    }

    public static List<List<Integer>> powerset(List<Integer> nums) {
        int n = nums.size();
        List<List<Integer>> list = new ArrayList<>();
        for (int i=1; i< Math.pow(2, n); i++) {
            List<Integer> li =  new ArrayList<>();
            for (int j=0; j<n; j++) {
                if ((i & (1 << j)) != 0) {
                    li.add(nums.get(j));
                }
            }
            list.add(new ArrayList<>(li));
        }
        return list;
    }

}
