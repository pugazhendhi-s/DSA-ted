package contest.hackerrank;

public class UtopianTree {

    public static void main(String[] args) {
        int n = 4;
        int ans = utopianTree(n);
        System.out.println(ans);
    }

    public static int utopianTree(int n) {
        int hts = 1;
        int i = 1;
        while (i++ <= n) {
            hts += (i % 2 == 0) ? 1 : hts;
        }
        return hts;
    }
}
