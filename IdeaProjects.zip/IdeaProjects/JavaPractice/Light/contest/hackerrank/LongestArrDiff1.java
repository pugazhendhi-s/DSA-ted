package contest.hackerrank;
import java.util.*;

public class LongestArrDiff1 {

    public static void main(String[] args) {
        List<Integer> list = new ArrayList<>(Arrays.asList(4, 6, 5, 3, 3, 1));
        int longest = pickingNumbers(list);
        System.out.println(longest);
    }
    public static int pickingNumbers(List<Integer> list) {

        Collections.sort(list);
        int longest = 1;
        for (int i=0; i<list.size(); i++) {
            int cur = 1;
            for (int j=i+1; j<list.size();j++) {
                cur += (Math.abs(list.get(i)-list.get(j)) < 2) ? 1 : 0;
            }
            longest = Math.max(longest, cur);
        }
        return longest;
    }
}
