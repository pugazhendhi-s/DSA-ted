package contest.infosys;

import java.util.Arrays;

public class Main {

    public static int maxScore(int[] A, int[] B) {
        int n = A.length;
        int[] primes = new int[n];
        int primeCount = 0;

        // Store all prime numbers from A in primes[]
        for (int i = 0; i < n; i++) {
            if (isPrime(A[i])) {
                primes[primeCount++] = A[i];
            } else {
                A[i] = 0;
            }
        }

        // Sort primes[] in descending order
        Arrays.sort(primes, 0, primeCount);
        for (int i = 0; i < primeCount / 2; i++) {
            int temp = primes[i];
            primes[i] = primes[primeCount - i - 1];
            primes[primeCount - i - 1] = temp;
        }

        // Assign the highest prime numbers to positions with 1 in B
        int score = 0;
        int index = 0;
        for (int i = 0; i < n; i++) {
            if (B[i] == 1) {
                A[i] = primes[index++];
                score += A[i];
            }
        }

        return score;
    }

    public static boolean isPrime(int num) {
        if (num < 2) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(num); i++) {
            if (num % i == 0) {
                return false;
            }
        }
        return true;
    }

    public static void main(String[] args) {
        int i=-1;
        for (i=0; i<5; ++i) {

            System.out.println(i);
        }
    }
}
