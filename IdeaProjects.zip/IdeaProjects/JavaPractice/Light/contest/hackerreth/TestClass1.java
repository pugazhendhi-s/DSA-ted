package contest.hackerreth;
import java.util.*;

public class TestClass1 {
    public static void main(String args[] ) throws Exception {

        Scanner sc = new Scanner(System.in);
        int V = sc.nextInt();
        Map<Integer, List<Pair>> adj = new HashMap<>();

        for (int i=0; i<V; i++) {
            adj.put(sc.nextInt(), new ArrayList<>());
        }
        int E = sc.nextInt();
        for (int i=0; i<E; i++) {
            int u = sc.nextInt();
            int v = sc.nextInt();
            int d = sc.nextInt();
            adj.get(u).add(new Pair(v, d));
        }
        int src = sc.nextInt();
        int dst = sc.nextInt();

        PriorityQueue<Pair> minHeap = new PriorityQueue<>((x, y) -> x.du - y.du);
        minHeap.offer(new Pair(src, 0));

        Map<Integer, Integer> dist = new HashMap<>();
        for (int key : adj.keySet()) {
            dist.put(key, (int)1e9);
        }
        dist.put(src, 0);

        while ( !minHeap.isEmpty()) {
            Pair p = minHeap.poll();
            int u = p.u;
            int du = p.du;

            for (Pair it : adj.get(u)) {
                int v = it.u;

                int dv = it.du;
                if (du + dv < dist.get(v)) {
                    dist.put(v, du+dv);
                    minHeap.offer(new Pair(v, du + dv));
                }
            }
        }
        int res = dist.get(dst);
        System.out.println(res);
    }
    static class Pair{
        int u;
        int du;

        public Pair(int u, int du) {
            this.u = u;
            this.du = du;
        }
    }
}