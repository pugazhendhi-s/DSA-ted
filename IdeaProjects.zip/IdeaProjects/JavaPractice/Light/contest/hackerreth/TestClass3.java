package contest.hackerreth;

import java.util.*;

public class TestClass3 {

    public static void main(String[] args) throws Exception {

        Scanner sc = new Scanner(System.in);
        int V = sc.nextInt();
        Map<Integer, List<Integer>> adj = new HashMap<>();

        for (int i=0; i<V; i++) {
            adj.put(sc.nextInt(), new ArrayList<>());
        }
        int E = sc.nextInt();
        for (int i=0; i<E; i++) {
            int u = sc.nextInt();
            int v = sc.nextInt();
            adj.get(u).add(v);
        }
        int src = sc.nextInt();
        int dst = sc.nextInt();
        List<Integer> list = new ArrayList<>();
        list.add(src);
        Set<Integer> vis = new HashSet<>();
        TestClass3 ts3 = new TestClass3();
        ts3.dfs(src, dst, vis, adj, list);
        for (int i=list.size()-1; i >= 0; i--) {
            System.out.print(list.get(i)+" ");
        }
    }

    private boolean dfs(int src, int dst, Set<Integer> vis, Map<Integer, List<Integer>> adj, List<Integer> list) {
        if (src == dst) {
            list.remove(list.size()-1);
            vis.remove(dst);
            return true;
        }
        vis.add(src);
        for (int it : adj.get(src)) {
            if (vis.add(it)) {
                if (dfs(it, dst, vis, adj, list)) {
                    list.add(it);
                    return true;
                }
            }
        }
        return false;
    }

}
